# Commercially Available Hardware Components
  * [Hyperspectral cameras](https://en.m.wikipedia.org/wiki/Hyperspectral_imaging)  
    * [Specim (Oulu, Finland)](http://www.specim.fi/)
    * [HySpex (Skedsmokorset, Norway)](http://www.hyspex.no/hyperspectral_imaging/)
    * [Surface Optics (San Diego, California)](https://surfaceoptics.com/applications/precision-agriculture-hyperspectral-sensors/)
    * [imec (Leuven, Belgium)](http://www2.imec.be/be_en/research/image-sensors-and-vision-systems/hyperspectral-imaging.html)
    * [SpecTIR (Reno, Nevada)](http://www.spectir.com/technology/hyperspectral-imaging/)
    * [HyVista (Sydney, Australia)](http://www.hyvista.com/technology/sensors/ultracam/)
    * [Tetracam ADC (Chatsworth, CA, USA)](http://www.tetracam.com/Products-ADC.htm)
    * [Southern Precision (Naracoorte, Australia)](http://www.southernprecision.com.au/product/model-505-greenseeker-handheld-with-trimble-recon-pda/)
    * [Apogee Instruments (Logan, UT, USA)](https://www.apogeeinstruments.co.uk/lab-spectroradiometer/)

  * [Millimeter wave scanners](https://en.m.wikipedia.org/wiki/Millimeter_wave_scanner) (which is a kind of [full body scanner](https://en.wikipedia.org/wiki/Full_body_scanner))  
    * L3 Technologies (New York, NY, USA) [ProVision 2](http://www.sds.l-3com.com/advancedimaging/provision-2.htm)  
  
  * High-speed ADC boards  
    * [ZTEX](http://www.ztex.de/) (with [BTCMiner](https://web.archive.org/web/20160528235832/http://www.ztex.de/btcminer/))
      * [v2.14a](http://shop.ztex.de/product_info.php?products_id=93) - [Xilinx Artix 7](https://www.xilinx.com/support/documentation/data_sheets/ds180_7Series_Overview.pdf) XC7A15T + Cypress CYUSB3033 EZ-USB FX3S, 100GPIO, USB 3.0 (200 MB/s), FPGA, [2ch 1MSPS 12bit ADC](https://www.xilinx.com/support/documentation/user_guides/ug480_7Series_XADC.pdf), on-board DSP, open-source SDK - 190€
      * [v2.16b](http://shop.ztex.de/product_info.php?products_id=76) - Xilinx Artix 7 XC7A200T + Cypress CY7C68013A EZ-USB FX2, 100GPIO, USB 2.0 (60 MB/s), FPGA, 2ch 1MSPS 12bit ADC, on-board DSP, open-source SDK - 440€
    * [Cronologic](http://cronologic.de/products/digitizer/) - Ndigo125M, 4ch, PCIe, 125MSPS 14bit ADC
    * [MC Measurement Computing](http://www.mccdaq.com/solutions/USB-Data-Acquisition.aspx)
      * [USB-1208HS](http://www.mccdaq.com/usb-data-acquisition/USB-1208HS-Series.aspx) - 8ch, 1MSPS 13bit ADC - 500 USD (62.50 USD/ch)
      * [USB-1616FS](http://www.mccdaq.com/usb-data-acquisition/USB-1616FS.aspx) - 16ch, 200kSPS 16bit ADC (daisy chainable) - 970 USD (60.63 USD/ch)
      * [USB-1616HS](http://www.mccdaq.com/usb-data-acquisition/USB-1616HS-Series.aspx) - 16([+48](http://www.mccdaq.com/usb-data-acquisition/AI-EXP48.aspx))ch, 1MSPS 16bit ADC - 1400(+600) USD (31.25 USD/ch)

  * High-speed ADC chips  
    * [Texas Instruments](http://www.ti.com/)  
      * [ADS1299](http://www.ti.com/product/ads1299) -  8ch, 16kSPS, 24bit, 8x sigma-delta ADC [ 56.43 USD/piece](http://www.digikey.com/product-detail/en/texas-instruments/ADS1299IPAG/296-35009-ND/3675170) (7.05 USD/ch)  
      * [ADS7953](http://www.ti.com/product/ads7953) - 16ch,  1MSPS, 12bit, 1x SAR ADC [ 10.36 USD/piece](http://www.digikey.com/product-detail/en/texas-instruments/ADS7953SRHBT/296-25845-1-ND/2237251) (10.36 USD/ch)    
      * [AFE5818](http://www.ti.com/product/afe5818) - 16ch, 65MSPS, 14bit, 16x ADC [166.14 USD/piece](http://www.digikey.com/product-search/en?keywords=afe5818)  
      * [AFE5801](http://www.ti.com/product/afe5801) - 16ch, 65MSPS, 12bit, 8x ADC [ 61.20 USD/piece](http://www.digikey.com/product-detail/en/texas-instruments/AFE5801IRGCT/296-24307-1-ND/2043069) (7.65 USD/ch)  
      * [AFE5851](http://www.ti.com/product/afe5851) - 16ch, 65MSPS, 12bit, 8x ADC [103.68 USD/piece](http://www.digikey.com/product-detail/en/texas-instruments/AFE5851IRGCT/296-24233-1-ND/2034912)    
      * [AFE0256](http://www.ti.com/product/afe0256) - 256ch, 26kSPS, 14bit, 4x SAR ADC [ 78.60 USD/piece](http://www.digikey.com/product-detail/en/texas-instruments/AFE5851IRGCT/296-24233-1-ND/2034912)    
      * **[AFE2256](http://www.ti.com/product/afe2256) - 256ch, 50kSPS, 16 bit, 4x SAR ADC [109.30 USD/piece](https://www.digikey.com/products/en?keywords=afe2256) ( 0.43 USD/ch)**  
    * [Analog Devices](http://www.analog.com/)  
      * [AD5590](http://www.analog.com/en/products/digital-to-analog-converters/da-converters/ad5590.html#product-overview) - 16ch,  1MSPS, 12bit, 1x SAR ADC [ 36.69 USD/piece](http://www.digikey.com/product-detail/en/analog-devices-inc/AD5590BBCZ/AD5590BBCZ-ND/1972262)  
      * [AD7490](http://www.analog.com/en/products/analog-to-digital-converters/ad-converters/ad7490.html#product-overview) - 16ch,  1MSPS, 12bit, 1x SAR ADC [ 12.61 USD/piece](http://www.digikey.com/product-detail/en/analog-devices-inc/AD7490BRUZ/AD7490BRUZ-ND/819881)    
      * [AD9249](http://www.analog.com/en/products/analog-to-digital-converters/ad-converters/ad9249.html#product-overview) - 16ch, 65MSPS, 14bit, 16x SAR ADC [161.35 USD/piece](http://www.digikey.com/product-detail/en/analog-devices-inc/AD9249BBCZ-65/AD9249BBCZ-65-ND/4494745) (10.08 USD/ch)  
      * [AD9637](http://www.analog.com/en/products/analog-to-digital-converters/ad-converters/ad9637.html#product-overview) - 8ch, 40MSPS, 12bit, 8x ADC [ 64.60 USD/piece](http://www.digikey.com/product-detail/en/analog-devices-inc/AD9637BCPZ-40/AD9637BCPZ-40-ND/2773682) ( 8.08 USD/ch)        
    * [Atmel/Microchip Technology](http://www.atmel.com/)  
      * **[XMEGA256A3BU](http://www.microchip.com/wwwproducts/en/ATxmega256A3BU) -  8ch, 2MSPS, 12bit, 2x SAR ADC [  7.34 USD/piece](https://www.digikey.com/product-detail/en/microchip-technology/ATXMEGA256A3BU-AU/ATXMEGA256A3BU-AU-ND/3046475) (0.92 USD/ch)**  
    * [Xilinx](http://www.xilinx.com)  
      * [Spartan-7](https://www.xilinx.com/products/silicon-devices/fpga/spartan-7.html) -  17ch, 1MSPS, 12bit, 2x ADC [ 50.92 USD/piece](https://www.digikey.com/product-detail/en/xilinx-inc/XC7S50-1FGGA484C/122-2039-ND/7380310) (2.99 USD/ch)  


  * Atmel AVR programmers and debuggers  
    * [**Atmel ICE**](http://www.atmel.com/tools/atatmel-ice.aspx) - Atmel-ICE is a powerful development tool for debugging and programming Atmel ARM® Cortex®-M based Atmel SAM and AVR® microcontrollers with on-chip debug capability. - 94.7-133.7 USD, [133.7 USD](http://www.digikey.com/product-detail/en/atmel/ATATMEL-ICE/ATATMEL-ICE-ND/4753379) with cables or the basic version for [94.7 USD](http://www.digikey.com/product-detail/en/atmel/ATATMEL-ICE-BASIC/ATATMEL-ICE-BASIC-ND/4753381)
    * [Atmel JTAGICE3](http://www.atmel.com/tools/jtagice3.aspx) - JTAGICE 3 is a mid-range development tool for Atmel 8- and 32-bit AVR microcontrollers with on-chip debugging for source level symbolic debugging, NanoTrace (if supported by the device) and device programming. - 133.7 USD
    * [Atmel AVR ONE!](http://www.atmel.com/tools/avrone_.aspx) - AVR ONE! is a professional development tool for all Atmel 8- and 32-bit AVR devices with on-chip debug capability. It is used for source level symbolic debugging, program trace, and device programming. The AVR ONE! supports the complete development cycle and is the fastest debugging tool offered from Atmel. - 655 USD
    * [Atmel Dragon](http://www.atmel.com/tools/avrdragon.aspx) - AVR Dragon sets a new standard for low cost development tools for 8- and 32-bit AVR devices with on-chip debug (OCD) capability. - 53.75 USD  
  * Development Kits
    * [Atmel ATxmega128A1U Xplained Kit](http://www.atmel.com/tools/ATXMEGAA1U-XPRO.aspx) - [44.44 USD](http://www.digikey.com/product-search/en?keywords=ATXMEGAA1U-XPRO)
    * [**Atmel ATxmega256A3BU Xplained Kit**](http://www.atmel.com/tools/XMEGA-A3BUXPLAINED.aspx) - [31.25 USD](http://www.digikey.com/product-search/en?keywords=ATXMEGAA3BU-XPLD)  
    * [Texas Instruments ADS1299EEGFE-PDK](http://www.ti.com/tool/ADS1299EEGFE-PDK) - ADS1299 Demonstration Kit [200.56 USD/piece](http://www.digikey.com/product-search/en?keywords=ADS1299EEGFE-PDK)
    * [Analog Devices EVAL-AD9637](https://wiki.analog.com/resources/eval/ad9257-65ebz_ad9637-80ebz) - AD9637 Evaluation Board [271.88 USD/piece](http://www.digikey.com/product-search/en/programmers-development-systems/evaluation-boards-analog-to-digital-converters-adcs/2622527?k=AD9637)  
  * Sensors and electrodes
    * [OpenBCI gold cup electrodes](http://shop.openbci.com/collections/frontpage/products/openbci-gold-cup-electrodes?variant=9056028163) - (x10) passive, gold cup electrodes on a 1m-long color-coded ribbon cable with female headers - 30 USD
    * [NVK Gold-Plated EEG Overmold Cup Electrode](http://www.nvk.com.tw/eeg-lead-wires/gold-plated-eeg.html)
    * [SenMed Cup electrode EEG cord](http://www.senmad.com/product/cup-electrode-eeg-cord/)
    * [Fiab EEG cup electrodes](http://www.fiab.it/en/prodotti.php?id=148)
    * [MVAP Ribbon Strand Gold Cup Electro](https://secure.mvapmed.com/prod-Ribbon_Strand_Gold_Cup_Electro-5351.aspx) (x11) gold plated 9mm discs, color coded ribbon cable, female 1.5mm connector - 175 USD
    * [Cephalon Reusable light wire Cup EEG Electrodes, Gold. 1 m lead, (bag of 10)](http://shop.cephalon.eu/Reusable-light-wire-Cup-EEG-Electrodes,-Gold-1-m/ItemDetails.aspx?9=GB&5=019-419400&11=308)
    * [Cephalon EEG Gold Cup Electrode 150 cm, Teflon Wire 10 pcs](http://shop.cephalon.eu/EEG-Gold-Cup-Electrode-150-cm,-Teflon-Wire-10-pcs/ItemDetails.aspx?9=GB&5=DEG101500-TF&11=1570)
    * [Greentek Gold Plated EEG Cup Electrodes](http://www.greenteksensor.com/eeg-accessories/gold-plated-eeg-cup-electrodes/)
  * High-precision GPS  
    * [RadioSense](http://www.radiosense.com/) - [Cheap Centimeter-Precision GPS For Cars, Drones, Virtual Reality](http://spectrum.ieee.org/tech-talk/transportation/self-driving/cheap-centimeterprecision-gps-for-cars-and-drones)
    * [Accuracy in the Palm of Your Hand](http://gpsworld.com/accuracy-in-the-palm-of-your-hand/)
    * [Reach: first affordable RTK GPS receiver](https://www.indiegogo.com/projects/reach-first-affordable-rtk-gps-receiver/#/updates)

# Atmel ATxmega µControllers
All Atmel ATxmega...A.. uControllers have a 2MSPS, 12bit, [successive-approximation (SAR) ADC](http://www.atmel.com/Images/doc8378.pdf), internal 32Mhz clock, DMA, 1.0V internal reference, integrated temperature sensor and all were designed in February 2008.  
## [A1 series](http://www.atmel.com/Images/Atmel-8067-8-and-16-bit-AVR-Microcontrollers-ATxmega64A1-ATxmega128A1_Datasheet.pdf)  
2 ADC, 2x4 result registers, 2x8 multiplexed, **100**-pin, **78** I/O, **EBI/EMI**, [ATxmega128A1U Xplained Kit](http://www.atmel.com/tools/ATXMEGAA1U-XPRO.aspx)  
## [A3 series](http://www.atmel.com/Images/Atmel-8068-8-and16-bit-AVR-XMEGA-A3-Microcontrollers_Datasheet.pdf)  
2 ADC, 2x4 result registers, 2x8 multiplexed, **64**-pin, **50** I/O, [ATxmega256A3BU Xplained Kit](http://www.atmel.com/tools/XMEGA-A3BUXPLAINED.aspx)  
## [A4 series](http://www.atmel.com/Images/Atmel-8069-8-and-16-bit-AVR-AMEGA-A4-Microcontrollers_Datasheet.pdf)  
1 ADC, 4 result registers, 12 multiplexed, 44-pin  
### Notes  
The U at the end of the model number means that it has a USB device controller. The B means that it has a real-time clock backup battery.  
Each ADC has four MUX selection registers with a corresponding result register. This means
that four channels can be sampled within 1.5 µs without any intervention by the application other
than starting the conversion.  
The ADC may be configured for 8- or 12-bit result, reducing the minimum conversion time (propagation
delay) from 3.5 µs for 12-bit to 2.5 µs for 8-bit result.  
The External Bus Interface (EBI) is used to connect external peripherals and memory for access through the data
memory space. When the EBI is enabled, data address space outside the internal SRAM becomes available using
dedicated EBI pins.
The EBI can interface external SRAM, SDRAM, and peripherals, such as LCD displays and other memory mapped
devices.  

# Price Estimation

* Atmel wholesale
  * ATXMEGA32A4-MH    1000+: [ 3.42 USD/piece](http://www.atmel.com/devices/atxmega32a4.aspx) (1.83 USD/ch)
  * ATXMEGA64A3-MHR   4000+: 6.56 USD/piece
  * ATXMEGA128A3-MHR  4000+: 6.56 USD/piece
  * ATXMEGA192A3-AU   1000+: 6.70 USD/piece
  * ATXMEGA256A3-AU   1000+: 7.88 USD/piece
  * ATXMEGA256A3U-MH  1000+: [ 5.95 USD/piece](http://www.atmel.com/devices/ATXMEGA256A3U.aspx)
  * ATXMEGA256A3BU-MH 1000+: 5.95 USD/piece
* TME.eu (with Hungarian VAT)
  * ATXMEGA32A4-CU 
    * 10+: [ 1.13 USD/piece](http://www.tme.eu/hu/details/atxmega32a4-cu/atmel-avr-smd-mikrovezerlok/atmel/) (0.28 USD/ch)
  * ATXMEGA32A4-MH 
    * 10+: [ 7.31 USD/piece](http://www.tme.eu/hu/details/atxmega32a4-mh/atmel-avr-smd-mikrovezerlok/atmel/) 
  * ATXMEGA256A3U-MH 
    * 1+: [13.93 USD/piece](http://www.tme.eu/hu/details/atxmega256a3u-mh/atmel-avr-smd-mikrovezerlok/atmel/)
    * 5+: [13.23 USD/piece](http://www.tme.eu/hu/details/atxmega256a3u-mh/atmel-avr-smd-mikrovezerlok/atmel/) (1.65 USD/ch)
  * ATXMEGA256A3U-AU 
    * 1+: [14.63 USD/piece](http://www.tme.eu/hu/details/atxmega256a3u-au/atmel-avr-smd-mikrovezerlok/atmel/) 
    * 5+: [13.78 USD/piece](http://www.tme.eu/hu/details/atxmega256a3u-au/atmel-avr-smd-mikrovezerlok/atmel/) (1.72 USD/ch)
* [DigiKey](http://www.digikey.com/) and [Mouser Electronics](http://www.mouser.com/)
  * ATXMEGA64A1U-AU (100-TQFP, 14x14mm)
    *  1+: [ 8.95 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA64A1U-AU/ATXMEGA64A1U-AU-ND/3789504) 
    * 10+: [ 8.06 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA64A1U-AU/ATXMEGA64A1U-AU-ND/3789504) (1.01 USD/ch)
  * ATXMEGA128A1U-AU (100-TQFP, 14x14mm)
    *  1+: [ 9.65 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA128A1U-AU/ATXMEGA128A1U-AU-ND/3441465) 
    * 10+: [ 8.68 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA128A1U-AU/ATXMEGA128A1U-AU-ND/3441465) (1.09 USD/ch)
  * **ATXMEGA64A3U-AU** (64-TQFP, 14x14mm)
    *   1+: [ 6.08 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA64A3U-AU/ATXMEGA64A3U-AU-ND/3046482)  
    *  10+: [ 5.47 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA64A3U-AU/ATXMEGA64A3U-AU-ND/3046482) (0.68 USD/ch) 
  * ATXMEGA256A3U-AU (64-TQFP, 14x14mm)
    *  1+: [11.09 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA256A3U-AU/ATXMEGA256A3U-AU-ND/3046477) 
    * 10+: [ 9.98 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA256A3U-AU/ATXMEGA256A3U-AU-ND/3046477) (1.25 USD/ch)
  * ATXMEGA32A4U-AU (44-TQFP, 10x10mm)
    *  1+: [ 5.06 USD/piece](http://www.digikey.com/product-detail/en/atmel/ATXMEGA32A4U-AU/ATXMEGA32A4U-AU-ND/3046479)  

# OpenCL CPUs and GPUs
OpenCL support varies by vendor: [AMD](http://developer.amd.com/tools-and-sdks/opencl-zone/) (v2.1), [nVidia](https://developer.nvidia.com/opencl) (v1.2), [Intel](https://software.intel.com/en-us/intel-opencl) (v2.1).  
The following articles list some OpenCL-enabled GPUs: [AMD GPUs](https://en.wikipedia.org/wiki/List_of_AMD_graphics_processing_units), [nVIDIA GPUs](https://en.wikipedia.org/wiki/GeForce_10_series), [Intel GPUs](https://en.wikipedia.org/wiki/List_of_Intel_graphics_processing_units).  
Benchmark scores were collected from the [CompuBench OpenCL 1.1 performance tests](https://compubench.com/result.jsp?benchmark=compu15d&test=572&text-filter=&order=median&ff-desktop=true&ff-smobile=true&os-OS_X_cl=true&os-Windows_cl=true&pu-CPU=true&pu-dGPU=true&pu-iGPU=true&pu-mGPU=true&pu-CPU-iGPU=true&pu-ACC=true&arch-x86=true&base=device).  
CUDA is an alternative to OpenCL, but only available on nVIDIA GPUs. Here are some [nVIDIA GeForce GTX OpenCL and CUDA performance tests](http://www.phoronix.com/scan.php?page=article&item=nv-linux-gtx1060&num=7).  

| Family | Model | Architecture | Memory Type | Memory Amount (GB) | Memory Speed (GB/s) | Single Precision (32bit) GFLOPS | OpenCL version | Benchmark: Particale (mIs) | Benchmark: Ocean (fps) | Price (HUF) | HUF / GFLOPS |
|:---------------|:--------------|:-------------:|------------------:|----:|:---:|------:|:---:|-----:|-----:|-----:|---:|
| AMD Radeon     | HD 6950       | TeraScale 3   |    256-bit GDDR5  |   1 | 160 |  2253 | 1.2 |  242 | 1178 |    - | - |
| AMD Radeon     | R9 380        | 3rdGen GCN    |    256-bit GDDR5  |   4 | 182 |  3476 | 2.0 |  556 | 1496 |    - | - |
| AMD Radeon     | R9 Fury       | 3rdGen GCN    |   4096-bit HBR    |   4 | 512 |  7168 | 2.0 | 1034 | 3612 | 107k | 14.92 |
| AMD Radeon     | Pro Duo       | 3rdGen GCN    | 2x4096-bit HBR    | 2x4 | 512 | 16380 | 2.0 |  994 | 3507 |    - | - |
| AMD Radeon     | RX 480        | 4thGen GCN    |    256-bit GDDR5  |   4 | 256 |  5161 | 2.0 |  832 | 2178 |  75k | 14.53 |
| AMD Radeon     | RX Vega 56    | 5thGen GCN    |   2048-bit HBM2   |   8 | 410 | 10544 | 2.2 |    ? |    ? | 175k | 16.59 |
| nVIDIA GeForce | GTX 1060      | GeForce 10    |    192-bit GDDR5  |   3 | 192 |  3470 | 1.2 | 1129 | 1667 |  64k | 18.44 |
| nVIDIA GeForce | GTX 1060      | GeForce 10    |    192-bit GDDR5  |   6 | 192 |  3855 | 1.2 | 1192 | 1758 |  83k | 21.53 |
| nVIDIA GeForce | GTX 1070 Ti   | GeForce 10    |    256-bit GDDR5  |   8 | 256 |  7816 | 1.2 |    ? |    ? |    ? |  ?.?  |
| nVIDIA GeForce | GTX 1080      | GeForce 10    |    256-bit GDDR5X |   8 | 320 |  8228 | 1.2 | 1585 | 2720 | 200k | 24.31 |
| Intel x64 CPU  | Q9300         | Intel Core 2  |    DDR2 or DDR3   |   - |  -  |    34 |   ? |   12 |   24 |    - | - |
| Intel x64 CPU  | 1017U         | Ivy Bridge    |            DDR3   |   - |  -  |     - |   ? |    7 |   12 |    - | - |
| Intel x64 CPU  | i3,i5,i7      | Skylake (6th) |   DDR3L or DDR4   |   - |  -  |     - | 2.1 |    - |    - |    - | - |
| Intel GPU      | HD Graphics   | Ivy Bridge    |               -   |   - |  -  |    96 |   ? |    7 |   12 |    - | - |
| Intel GPU      | HD 510        | Skylake (6th) |               -   |   - |  34 |   182 | 2.0 |   98 |  143 |    - | - |
| Intel GPU      | HD 530        | Skylake (6th) |               -   |   - |  34 |   442 | 2.0 |  220 |  290 |    - | - |
| Intel GPU      | Iris Pro 580  | Skylake (6th) |               -   |   - |  34 |  1152 | 2.0 |  433 |  434 |    - | - |


# PC-based USB Digital Oscilloscopes  
## [Hantek](http://www.hantek.com/en/)  
[Hantek 6022BL](http://www.hantek.com/en/ProductDetail_2_153.html) - 20 MHz, 2(Digital)+16(Logic), 48MSa/s, 20mV/div～5V/div input sensitivity, Logic Analyzer - 90 USD  
Hantek 6074BD - 70 Mhz, 4 independent analog channels, 1GSa/s real-time sampling rate, 2mV-10V/DIV input sensitivity, 1 generator channel, FFT - 270 USD  
Hantek DSO3104A - 100 Mhz, 4 independent analog channels, 1GSa/s real-time sampling rate, 1mV to 10V/div input sensitivity, 1 generator channel, Logic Analyzer , FFT - 427 USD  
Hantek DSO3254A - 250 Mhz, 4 independent analog channels, 1GSa/s real-time sampling rate, 1mV to 10V/div input sensitivity, 1 generator channel, Logic Analyzer , FFT - 507 USD  
  
Hantek 6204BD - 100 Mhz, 4 independent analog channels, 1GSa/s real-time sampling rate, 2mV-10V/DIV input sensitivity, 1 generator channel  
Hantek 6104BD - 200 Mhz, 4 independent analog channels, 1GSa/s real-time sampling rate, 2mV-10V/DIV input sensitivity, 1 generator channel  
Hantek 6254BD - 250 Mhz, 4 independent analog channels, 1GSa/s real-time sampling rate, 2mV-10V/DIV input sensitivity, 1 generator channel  
Hantek iDSO1070A - 70 Mhz, 2 independent analog channels, 250MSa/s real-time sampling rate, 10mV/div～5V/div input sensitivity, WiFi  
Hantek DSO3064A - 60 Mhz, 4 independent analog channels, 200MSa/s real-time sampling rate, 10mV to 5V/div input sensitivity, 1 generator channel, no Logic Analyzer , FFT  
  
## SainSmart  
DDS120 - 20 Mhz, 2 channels, 50 MSa/s, 1x1 kHz square wave generator channel  
DDS140 - 40 Mhz, 2 channels, 200 MSa/s, 1x1 kHz square wave generator channel - 110 USD  
  
## [BitScope](http://bitscope.com/)  
BitScope MICRO BS05P - 20 Mhz, 2 analog channels, 40 MSa/s, 1x5-250kHz generator channel, Logic Analyzer, SPI decoder - 165 USD + 30 USD probe  
USB BitScope 10 BS10U - 100 Mhz, 2 analog channels, 40 MSa/s, 1 generator channel, SPI decoder - [245 USD](http://my.bitscope.com/store/?p=list&a=list&i=cat+0)  
  
## JYETech  
[JYETech DSO150 (15001K)](http://www.jyetech.com/Products/LcdScope/e150.php) - 200KHz, 1MSa/s, 5mV/div-20V/div - 40 USD  
  
## [PicoScope](https://www.picotech.com/oscilloscope/2000/picoscope-2000-specifications)
[PicoScope 2204A](https://www.picotech.com/oscilloscope/2000/picoscope-2000-specifications) - 10 MHz - 130 USD  
[PicoScope 2205A](https://www.picotech.com/oscilloscope/2000/picoscope-2000-specifications) - 25 MHz - 210 USD  
  
## [LabNation](https://www.lab-nation.com)
[LabNation SmartScope](https://www.lab-nation.com/) - - 264 USD  
  
## [Velleman](http://www.velleman.eu)
[Velleman PCSU200](http://www.velleman.eu/products/view/?id=407512) - - 135 USD  

## [Digilent](http://store.digilentinc.com)
[Analog Discovery 2](http://store.digilentinc.com/analog-discovery-2-100msps-usb-oscilloscope-logic-analyzer-and-variable-power-supply/) - 2x 30MHz 14-bit analog oscilloscope channels (100 MSa/s), 2x 12MHz 14-bit generator channel, 16-channel digital logic analyzer, Spectrum Analyzer, Digital Bus Analyzers (SPI, I²C, UART, Parallel), Two programmable power supplies - 279 USD  
[Analog Discovery 2 Pro Bundle](http://store.digilentinc.com/analog-discovery-2-pro-bundle/) - 299.99 USD  
[OpenScope MZ](http://store.digilentinc.com/openscope-mz-open-source-all-in-one-instrumentation/) - - 89 USD

# [Direct digital synthesizer](https://en.wikipedia.org/wiki/Direct_digital_synthesizer) (DDS)
## JYETech 
[JYETech FG095](http://www.jyetech.com/Products/085/e08503.php) - - 49 USD