Venus-256 is a [256-channel data acquisition system (DAS)](http://www.ti.com/lit/ml/slyp162/slyp162.pdf) to provide a bio-potential reading in the 0.4Hz - 500kHz frequency range using a [flat panel detector (FPD)](https://en.wikipedia.org/wiki/Flat_panel_detector), displaying the processed data as an [RGB-colored](https://en.wikipedia.org/wiki/RGB_color_model), [hyperspectral image](https://en.wikipedia.org/wiki/Hyperspectral_imaging) on a PC.  

# Requirements
The achieve the 0.4Hz - 500kHz frequency range we would need at least 1MSPS ADCs (because of the [Nyquist-frequency](https://en.wikipedia.org/wiki/Nyquist_frequency)). The electromagnetic fields we are going to measure are very week, so high SNR, high bitrate and low analog reference are needed. The SNR values for delta-sigma ADC are usually better than the SAR ADC, and also delta-sigmas usually have higher bitrate.  
Bi-polar input would be also good, because the field changes are independent from the device's power supply.  
So the ideal ADC is a 1MSPS 16-bit delta-sigma ADC with 1V reference and bi-polar input.  
  
The lower end of the frequency range we need to measure is 0.4Hz. This means that ween need to store at least 1/0.4 seconds of data to be able to detect that frequency. This 2.5 seconds of data means 2.5 seconds * 16 bit/sample * 1M samples/second = 5 megabytes of data for every channel, so 1.28 gigabytes of RAM just for the raw ADC data.  
As a counter-measure we can define two sampling modes: low speed (1kSPS) and high speed (1MSPS). In the 1kSPS mode we can have the 0.4 Hz - 500 Hz and in the 1MSPS the 400 Hz - 500k Hz range, only using 5 kilobytes of ADC data/channel.  
This means that our RAM requirement is somewhat more than 5k * 256 = 1.28 megabytes for the ADC data.
  
Computations will be needed on all channels. [Fast Fourier Transformation (FFT)](https://en.wikipedia.org/wiki/Fast_Fourier_transform) would be ideal, but I don't think they are feasible, unless we use FPGAs or ASICs. As an alternative we can use an the [Goertzel algorithm](https://en.wikipedia.org/wiki/Goertzel_algorithm), which tells us how strong a signal is at a particular frequency.
In order to be able to display a colorful, RGB image at the end, we need to have at least three Goerzel calculations per channel, ideally at least 50 times per second.  
The computation power estimation is more difficult and the use of an FPGA would help a lot.  
  
The processed data should be transferred to the PC fast enough to have a solid user experience, so the refresh rate should be close to 50/seconds, and the latency should be lower then 100 milliseconds.  
If using three 8-bit Goertzels per channel, the estimated data rate should be in the 350-400 kbits/second range, which is easily handled by even [USB 1.0](https://en.wikipedia.org/wiki/USB) and potentially handled by [Bluetooth Low Energy](https://en.wikipedia.org/wiki/Bluetooth_Low_Energy) too [(BLE 4.0 has 260 kbps and BLE 4.2 has 650 kbps maximum transfer rate)](https://www.anandtech.com/show/8770/bluetooth-42-core-specifications-finalized).  
  
[In-system (in-situ) programming](https://www.flashrom.org/ISP), firmware upgradability, USB or battery power source, .NET Core-based driver and API, WebSockets, Unity3D GUI, three-dimensional dual-tetrahedron or Sierpinski Gasket fractal antenna.  
Prepare for FPGA architecture and [Raspberry Pi 3 B+](https://www.raspberrypi.org/products/raspberry-pi-3-model-b-plus/) interfacing with [Windows IoT Core](https://developer.microsoft.com/en-us/windows/iot/downloads).  
  
# Hardware Components
  
Fortunately there are endless combinations of powerful hardware components to build this prototype, so I decided to list a few viable combinations and the explanation why are they a good or a not-so-good fit for this project.  
  
## Architecture #1 (discarded)
8x [Analog Devices ADG732](http://www.analog.com/media/en/technical-documentation/data-sheets/ADG726_732.pdf) - 32:1 multiplexer (with 23 ns typical transition time) - 12 USD  
8x [Analog Devices AD9261](http://www.analog.com/media/en/technical-documentation/data-sheets/AD9261.pdf) - 16-bit, 160MSPS (configurable to 32MSPS (1MSPS/channel)), delta-sigma ADC (with unknown settling-time and a 32× oversampled fifth-order continuous time loop filter), 16-bit parallel output, 0.5 Gbps @ 32MSPS - 52 USD  
4x [Intel 10CL120](https://www.altera.com/products/fpga/cyclone-series/cyclone-10/cyclone-10-lp/overview.html) FPGA for Goertzel/FFT, 2.5MB RAM, 1.12 Gbps, LVDS - 160 USD  
1x [Atmel ATSAME70Q21](http://www.microchip.com/wwwproducts/en/ATSAME70Q21) MCU Cortex-M7 300Mhz CPU, 384kB RAM, 480Mhz USB, 24x2 12bit 2MSPS SAR ADC, SD-CARD, 5xSPI - 16 USD  
  
This architecture was discarded because of the steep and expensive learning curve of FPGAs.  
  
## Architecture #2 (discarded)
  
1x [Texas Instruments DDC2256A](http://www.ti.com/lit/ds/symlink/ddc2256a.pdf) - 256-Channel, Current-Input, Analog-To-Digital Converter, serial LVDS output - 350 USD  
1x FPGA for Goertzel/FFT  
1x [Atmel ATSAME70Q21](http://www.microchip.com/wwwproducts/en/ATSAME70Q21) MCU Cortex-M7 300Mhz CPU, 384kB RAM, 480Mhz USB, 24x2 12bit 2MSPS SAR ADC, SD-CARD, 5xSPI - 16 USD
  
This architecture was discarded because of Texas Instruments didn't provide me any documentation about the DDC2256A after requesting it.  
  
## Architecture #3 (discarded)
  
8x [Analog Devices ADG732](http://www.analog.com/media/en/technical-documentation/data-sheets/ADG726_732.pdf) - 32:1 multiplexer (with 23 ns typical transition time) - 12 USD  
8x [Analog Devices AD7768](http://www.analog.com/en/products/analog-to-digital-converters/ad7768.html) - 8-Channel, 24-Bit, 256kSPS, simultaneous sampling 8x delta-sigma ADC, power scaling, 110.8 kHz BW, 8-bit parallel output - 38 USD   
1x FPGA for Goertzel/FFT  
1x [Atmel ATSAME70Q21](http://www.microchip.com/wwwproducts/en/ATSAME70Q21) MCU Cortex-M7 300Mhz CPU, 384kB RAM, 480Mhz USB, 24x2 12bit 2MSPS SAR ADC, SD-CARD, 5xSPI - 16 USD  
  
This architecture was discarded because AD7768 has parallel only output targeted for FPGAs and the difficulties would arise from the manual [time division multiplexing](https://en.wikipedia.org/wiki/Time-division_multiplexing).  
    
### Evaluation kits for #3 (discarded)
  
1x [Analog Devices EVAL-AD7768](http://www.analog.com/en/design-center/evaluation-hardware-and-software/evaluation-boards-kits/EVAL-AD7768.html) - features the AD7768 24-bit, 256 kSPS, analog-to-digital converter (ADC) - 175 USD  
1x [Analog Devices SDP-H1](http://www.analog.com/en/design-center/evaluation-hardware-and-software/evaluation-boards-kits/eval-sdp-h1.html) - EVAL-SDP-CH1Z, [Xilinx Spartan 6](https://www.xilinx.com/products/silicon-devices/fpga/spartan-6.html) FPGA and an [Blackfin ADSP-BF527](http://www.analog.com/en/products/processors-dsp/blackfin/adsp-bf527.html) processor - 220 USD  
  
## Architecture #4 (potentially suitable)
  
16x [Analog Devices AD7616](http://www.analog.com/en/products/analog-to-digital-converters/ad7616.html) 16-Channel DAS with 16-Bit, bipolar input, dual simultaneous sampling 2x 1MSPS SAR ADC, 16-bit parallel output and 16+Mhz dual SPI output - 25 USD  
4x [Atmel ATSAME70Q21](http://www.microchip.com/wwwproducts/en/ATSAME70Q21) MCU Cortex-M7 CPU @ 300Mhz, 384kB RAM, 480Mhz USB, 24x2 12bit 2MSPS SAR ADC, SD-CARD, 5xSPI - 16 USD  
1x [Raspberry Pi 3 Model B+](https://www.raspberrypi.org/products/raspberry-pi-3-model-b-plus/) MPU Broadcom BCM2837B0, Cortex-A53 (ARMv8) 64-bit SoC @ 1.4GHz, 1GB LPDDR2 SDRAM, USB 2.0, Bluetooth 4.2, SD-CARD, 2xSPI - 35 USD
  
The AD7616 has two 1MSPS 16-bit ADCs (not delta-sigmas though) and it supports SPI output. This would mean that if we use just 2 sensors we can get 1MSPS and if we use all the 16 we are going to get 128kSPS. The analog low pass filters, the burst mode, the bipolar input and 2.5/4V internal reference support are also a plus.  
The ATSAME70Q21s should be able to handle up to 8 channels of SPI inputs with its five UARTs and three USARTs, it has just enough (384kbytes) RAM to store 5kbytes of raw ADC data per channel, which is enough to implement the 1MSPS/1kSPS [decimated](https://en.wikipedia.org/wiki/Decimation_(signal_processing)) and the 300Mhz MCU should be fast enough for the 64 channels' three Goerzel calculations at a reasonable rate.  
The Raspberry Pi would be perfect for interfacing it with the PC.   

### Evaluation kits for #4
  
1x [Atmel ATSAME70-XPLD](http://www.microchip.com/DevelopmentTools/ProductDetails.aspx?PartNO=ATSAME70-XPLD) - ATSAME70Q21 + 2 MB RAM + SD-slot + Ethernet socket + JTAG + 3 Atmel XPRO Extension Headers - 38 USD  
1x [Atmel ATWINC3400-XPRO](https://www.microchip.com/DevelopmentTools/ProductDetails.aspx?PartNO=ATWINC3400-XPRO) - The WINC3400 is an IEEE 802.11 b/g/n/BLE4.0 IoT network controller SoC. - 31 USD  
1x [Analog Devices EVAL-AD7616](http://www.analog.com/en/design-center/evaluation-hardware-and-software/evaluation-boards-kits/EVAL-AD7616.html) - full featured evaluation board designed to easily evaluate all features of both the AD7616 and AD7616-P analog-to-digital converters (ADCs) - 62 USD  
1x [Analog Devices EVAL-SDP-CB1Z](http://www.analog.com/en/design-center/evaluation-hardware-and-software/evaluation-boards-kits/SDP-B.html) - SDP-B, [Blackfin ADSP-BF527](http://www.analog.com/en/products/processors-dsp/blackfin/adsp-bf527.html) processor - 109 USD  

## Costs

### Development costs:     

#### New Equipment: ((US: $588 + [0% import tax](http://ec.europa.eu/taxation_customs/dds2/taric/taric_consultation.jsp?Lang=en&Taric=8471500000&Area=US&Level=2&SimDate=20180315&GoodsText=&OrderNum=&StartPub=&EndPub=&Regulation=&LastSelectedCode=8471000000)) OR (EU: $672)) + 27% VAT  
 * $380 - 1x [Analog Discovery 2 Pro Bundle](https://store.digilentinc.com/analog-discovery-2-pro-bundle/) ($299 @ [Digilent US](https://store.digilentinc.com/analog-discovery-2-pro-bundle/))  
    * 1x [410-321: Analog Discovery 2](https://store.digilentinc.com/analog-discovery-2-100msps-usb-oscilloscope-logic-analyzer-and-variable-power-supply/) ($300 @ [FDH EU](http://fdh.hu/products/808477), $279 @ [Digilent US](https://store.digilentinc.com/analog-discovery-2-100msps-usb-oscilloscope-logic-analyzer-and-variable-power-supply/))  
    * 1x [410-263: BNC Adapter Board](https://store.digilentinc.com/bnc-adapter-board-for-the-analog-discovery/) ($22 @ [FDH EU](http://fdh.hu/products/666549), $20 @ [Digilent US](https://store.digilentinc.com/bnc-adapter-board-for-the-analog-discovery/))  
    * 1x [460-004: BNC Oscilloscope x1/x10 Probes (Pair)](https://store.digilentinc.com/bnc-oscilloscope-x1-x10-probes-pair/) ($20 @ [Digilent US](https://store.digilentinc.com/bnc-oscilloscope-x1-x10-probes-pair/))  
    * 1x [240-052: Mini Grabber Test Clips (6-pack)](https://store.digilentinc.com/mini-grabber-test-clips-6-pack-for-use-with-analog-discovery-flywire/) ($15 @ [Digilent US](https://store.digilentinc.com/mini-grabber-test-clips-6-pack-for-use-with-analog-discovery-flywire/))
 * $150 - 1x [Analog Devices EVAL-SDP-CB1Z](http://www.analog.com/en/design-center/evaluation-hardware-and-software/evaluation-boards-kits/SDP-B.html) ($118 @ [FDH EU](http://fdh.hu/products/494844), $113 @ [Mouser EU](https://eu.mouser.com/ProductDetail/Analog-Devices/EVAL-SDP-CB1Z?qs=WIvQP4zGanjKLJTWj3jiIw%3d%3d), $109 @ [DigiKey US](https://www.digikey.com/products/en?keywords=EVAL-SDP-CB1Z))  
 * $ 89 - 1x [Analog Devices EVAL-AD7616](http://www.analog.com/en/design-center/evaluation-hardware-and-software/evaluation-boards-kits/EVAL-AD7616.html) (~~$70~~ $85 @ [FDH EU](http://fdh.hu/products/903147), $64 @ [Mouser EU](https://eu.mouser.com/ProductDetail/Analog-Devices/EVAL-AD7616SDZ?qs=sGAEpiMZZMuYaq4aOfOV%252bHESLrKQGbVRx1U%2fybyyYgg%3d), $62 @ [DigiKey US](https://www.digikey.com/product-detail/en/analog-devices-inc/EVAL-AD7616SDZ/EVAL-AD7616SDZ-ND/6566160))  
 * $ 59 - 1x [Atmel ATSAME70-XPLD](http://www.microchip.com/DevelopmentTools/ProductDetails.aspx?PartNO=ATSAME70-XPLD) ($46 @ [FDH EU](http://fdh.hu/products/794729), $38 @ [DigiKey US](https://www.digikey.com/products/en?keywords=ATSAME70-XPLD))  
 * $ 81 - 1x Raspberry Pi 3 Model B+ kit ($81 @ [MalnaPC EU](https://malnapc.hu/yis/revolt-pi3b-plus-official-kit), $80 @ [CanaKit US](https://www.canakit.com/raspberry-pi-3-model-b-plus-starter-kit.html))  

#### New Materials: $500 + 27% VAT  
 * $ 39 - 1x [Raspberry Pi 3 Model B+](https://www.raspberrypi.org/products/raspberry-pi-3-model-b-plus/) ($39 @ [RPiBolt.hu](https://www.rpibolt.hu/Raspberry-Pi-3-Model-B-Plus))
 * $ 62 - 4x [Atmel ATSAME70Q21](http://www.microchip.com/wwwproducts/en/ATSAME70Q21) ($15.58 @ [FDH.hu](http://fdh.hu/products/805816))   
 * $399 - 16x [Analog Devices AD7616](http://www.analog.com/en/products/analog-to-digital-converters/ad7616.html) ($24.92 @ [FDH.hu](http://fdh.hu/products/903155))  
  
#### Fabrication:

  
### Net cost per unit:  
  
### Order(s)

2018-04-06 FDH #099af65788 - Order Placed  
2018-04-06 MalnaPC #22929 - Order Placed  
2018-04-06 MalnaPC #22929 - [Dispatched Posta Tracking #PN1C156406261](https://posta.hu/ugyfelszolgalat/nyomkovetes?ids=PN1C156406261)  
2018-04-09 FDH #099af65788 - [Dispatched GLS Tracking #00451671382](http://online.gls-hungary.com/tt_page.php?lng=hu&tt_value=00451671382)  

# Building blocks

The **cell** is a sensor-hub, so its function is to collect data from multiple sensors/antennas, connected to multiple ADCs.  
Every cell has 64 sensors arranged in a 8x8 2D matrix. Cells can be daisy-chained, so the theoretical limit of cells depends only on the protocol.  
The **organizer**, which collects the data from the cells, organizes the data and sends it through its USB interface to the PC.  

# Software components

### Firmware

### USB driver

### Connectivity
  
# Development  

## Milestones  

## Net hours  

# Data workflow
  
# Results

# Conclusion