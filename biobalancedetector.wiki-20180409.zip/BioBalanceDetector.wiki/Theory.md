Definitions
-----------

* [Spectroscopy](https://en.wikipedia.org/wiki/Spectroscopy)

  Spectroscopy /spɛkˈtrɒskəpi/ is the study of the interaction between matter and electromagnetic radiation. Historically, spectroscopy originated through the study of visible light dispersed according to its wavelength, by a prism. Later the concept was expanded greatly to include any interaction with radiative energy as a function of its wavelength or frequency. Spectroscopic data is often represented by an emission spectrum, a plot of the response of interest as a function of wavelength or frequency.

  Spectroscopy and spectrography are terms used to refer to the measurement of radiation intensity as a function of wavelength and are often used to describe experimental spectroscopic methods. Spectral measurement devices are referred to as spectrometers, spectrophotometers, spectrographs or spectral analyzers.

  Spectroscopy is used in physical and analytical chemistry because atoms and molecules have unique spectra. As a result, these spectra can be used to detect, identify and quantify information about the atoms and molecules. Spectroscopy is also used in astronomy and remote sensing on earth. Most research telescopes have spectrographs. The measured spectra are used to determine the chemical composition and physical properties of astronomical objects (such as their temperature and velocity).

  Our goal is to measure electromagnetic radiation.

  Emission indicates that radiative energy is released by the material. A material's blackbody spectrum is a spontaneous emission spectrum determined by its temperature; this feature can be measured in the infrared by instruments such as the Atmospheric Emitted Radiance Interferometer (AERI).[4] Emission can also be induced by other sources of energy such as flames or sparks or electromagnetic radiation in the case of fluorescence.

  * [Absorption spectroscopy](https://en.wikipedia.org/wiki/Absorption_spectroscopy)

  Absorption spectroscopy refers to spectroscopic techniques that measure the absorption of radiation, as a function of frequency or wavelength, due to its interaction with a sample. The sample absorbs energy, i.e., photons, from the radiating field. The intensity of the absorption varies as a function of frequency, and this variation is the absorption spectrum. Absorption spectroscopy is performed across the electromagnetic spectrum.

  * [Fourier transform spectroscopy](https://en.wikipedia.org/wiki/Fourier_transform_spectroscopy)
  
  Fourier transform spectroscopy is a measurement technique whereby spectra are collected based on measurements of the coherence of a radiative source, using time-domain or space-domain measurements of the electromagnetic radiation or other type of radiation.

  The term Fourier transform spectroscopy reflects the fact that in all these techniques, a Fourier transform is required to turn the raw data into the actual spectrum, and in many of the cases in optics involving interferometers, is based on the Wiener–Khinchin theorem.

  * [Hyperspectral imaging](https://en.wikipedia.org/wiki/Hyperspectral_imaging)

  Hyperspectral imaging, like other spectral imaging, collects and processes information from across the electromagnetic spectrum. The goal of hyperspectral imaging is to obtain the spectrum for each pixel in the image of a scene, with the purpose of finding objects, identifying materials, or detecting processes.

    Whereas the human eye sees color of visible light in mostly three bands (red, green, and blue), spectral imaging divides the spectrum into many more bands. This technique of dividing images into bands can be extended beyond the visible. In hyperspectral imaging, the recorded spectra have fine wavelength resolution and cover a wide range of wavelengths.

    [See the unseen with hyperspectral imaging | Abi Ramanan | TEDxEastEnd](https://www.youtube.com/watch?v=EaeRlzm-tWM)  
    [CAVE Multispectral Image Database](http://www1.cs.columbia.edu/CAVE/databases/multispectral/)

  * [Video spectroscopy](https://en.wikipedia.org/wiki/Video_spectroscopy)

  Video spectroscopy combines spectroscopic measurements with video technique. This technology has resulted from recent developments in hyperspectral imaging. A video capable imaging spectrometer can work like a camcorder and provide full frame spectral images in real-time that enables advanced (vehicle based) mobility and hand-held imaging spectroscopy. 

  * [Imaging spectrometer](https://en.wikipedia.org/wiki/Imaging_spectrometer)

  An imaging spectrometer is an instrument used in hyperspectral imaging and imaging spectroscopy to acquire a spectrally-resolved image of an object or scene, often referred to as a datacube due to the three-dimensional representation of the data. Namely, two axes of the image corresponds to distance and the third to wavelength. The principle of operation is the same as that of the simple spectrometer, but special care is taken to avoid optical aberrations for better image quality.

  Example imaging spectrometer types include: filtered camera, whiskbroom scanner, pushbroom scanner, integral field spectrograph (or related dimensional reformatting techniques), wedge imaging spectrometer, Fourier transform imaging spectrometer, computed tomography imaging spectrometer (CTIS), image replicating imaging spectrometer (IRIS), coded aperture snapshot spectral imager (CASSI), and image mapping spectrometer (IMS).

  * [Spectroradiometer](https://en.wikipedia.org/wiki/Spectroradiometer)

  Spectroradiometers are devices designed to measure the spectral power distribution of a source. From the spectral power distribution, the radiometric, photometric, and colorimetric quantities of light can be determined in order to measure, characterize, and calibrate light sources for various applications.

  * [Spectrum analyzer](https://en.wikipedia.org/wiki/Spectrum_analyzer)

  A spectrum analyzer measures the magnitude of an input signal versus frequency within the full frequency range of the instrument. The primary use is to measure the power of the spectrum of known and unknown signals. The input signal that a spectrum analyzer measures is electrical; however, spectral compositions of other signals, such as acoustic pressure waves and optical light waves, can be considered through the use of an appropriate transducer. Optical spectrum analyzers also exist, which use direct optical techniques such as a monochromator to make measurements.

  By analyzing the spectra of electrical signals, dominant frequency, power, distortion, harmonics, bandwidth, and other spectral components of a signal can be observed that are not easily detectable in time domain waveforms. These parameters are useful in the characterization of electronic devices, such as wireless transmitters.

  The display of a spectrum analyzer has frequency on the horizontal axis and the amplitude displayed on the vertical axis. To the casual observer, a spectrum analyzer looks like an oscilloscope and, in fact, some lab instruments can function either as an oscilloscope or a spectrum analyzer.

  * [Spectrograph](https://en.wikipedia.org/wiki/Spectrograph)

  A spectrograph is an instrument that separates light into a frequency spectrum and records the signal using a camera. There are several kinds of machines referred to as spectrographs, depending on the precise nature of the waves. The term was first used in July, 1876 by Dr. Henry Draper when he invented the earliest version of this device, and which he used to take several photographs of the spectrum of Vega. This earliest version of the spectrograph was cumbersome to use and difficult to manage.

  One way to define a spectrograph is as a device that separates light by its wavelength and records this data. A spectrograph typically has a multi-channel detector system or imaging system that detects the spectrum of light.

* Lasers

* [Transcranial electrical stimulation methods](http://www.tandfonline.com/doi/full/10.1080/09602011.2011.557292?scroll=top&needAccess=true)
  * tACS - transcranial alternating current stimulation - Dr. Ursula Voss: 40Hz -> lucid dream
  * tDCS - transcranial direct current stimulation
  * [DIY tDCS](http://www.diytdcs.com/)
  * [Open tDCS](https://github.com/boinger/tdcs) - tDCS Regulation Circuits - Open Source Hardware

* [EDA - Electrodermal activity](https://en.wikipedia.org/wiki/Electrodermal_activity)

* ADC/DAC
  * [Types of ADCs and how they work](http://www.mccdaq.com/PDFs/specs/Analog-to-Digital.pdf)
  * [DSD format](https://en.wikipedia.org/wiki/Direct_Stream_Digital)
  * [DSD256 DAC](http://lhlabs.com/products/pulse-dac/)

* CCDs
  * [CCDs - charge-coupled devices](https://en.wikipedia.org/wiki/Charge-coupled_device) - CCDs are array of [MOSFETs](https://en.wikipedia.org/wiki/MOSFET)
  * [Three-CCD Camera](https://en.wikipedia.org/wiki/Three-CCD_camera)
  * [CFA](https://en.wikipedia.org/wiki/Color_filter_array)
  * [Bayer filter](https://en.wikipedia.org/wiki/Bayer_filter)
  * Cooling of CCDs  
  * DSLR is not good because of the mirror
  * Compacts are not good because of their fixed lenses
  * CCD Cameras are for astronomers (and [it has too limited frequency range](https://www.sbig.com/astronomy/about-ccd-imaging/how-to-choose-your-first-camera/))
  * [Pinhole lens](https://www.youtube.com/watch?v=N_yJSPlQpJA)

* [PEMF](https://en.wikipedia.org/wiki/Pulsed_electromagnetic_field_therapy)  
  * [The God Helmet’s Weak Fields are Sufficient to Influence Brain Activity](https://sacredneurology.com/2015/06/13/the-god-helmets-weak-fields-are-sufficient-to-influence-brain-activity-a-blog-by-dr-m-a-persinger/)  
    "Our brains are richly populated with crystalline magnetite, containing 5 million such crystals per gram (Kirschvink, 1992 A).  They appear in chains ('magnetosomes')."  
    List of experiments with magnetic fields of strength between 5 picoTesla and 2.5 milliTesla that had effects on humans.

  Today, the majority of PEMF wellness devices resemble a typical yoga mat in dimensions but are slightly thicker to house several flat spiral coils to produce an even electromagnetic field. A frequency generator is then used to energize the coils to create a "pulsed" electromagnetic field.

* Quantum Biofeedback / SCIO - Scientific Consciousness Interface Operation system
  * [EPFX](http://www.buyusedscio.com/quantum-biofeedback/)
  * [Quantum Biofeedback Conference 2016](https://www.scio-eductor.com/events-eng/world-conference-2016)
  * [Scio Suli Kft. (Eclosion Kft.)](http://www.sciosuli.hu/BPRSPage.html) - 1089 Budapest Kálvária tér 2., 2310 Szigetszentmiklós Gyártelep 12001/33 Hrsz, [Facebook](https://www.facebook.com/Scio-Suli-Hungary-Kft-136171903116858/timeline/), [LinkedIn](https://www.linkedin.com/vsearch/p?company=Eclosion+Kft&trk=prof-exp-company-name), [staff](https://www.scio-eductor.com/contact-eng/the-staff)
  * [QX Ltd.](https://www.qxworldltd.com/) - 2310 Szigetszentmiklós Tököli út 19/B
  * [SCIO vs. Indigo](http://www.scio.in/indigo.php)
  * [Quantum Energy Wellness](http://quantumenergywellness.com/index-7.htm)
  * [Biorezonancia.net](http://www.biorezonancia.net/scio)
  * [A biorezonanciáról érthetően](http://www.vitalland.hu/biorezonancia)
  * [Bioenergetikus](http://www.bioenergetikus.hu/)

* Nature
  * How do human eyes work?
    * [How eyes see color?](http://enchroma.com/technology/)  
      > The retina contains approximately 6 million retinal cone cells. Each cell is ‘color specific,’ responding mainly to light of specific frequencies. The three different types of cone cells correspond to the three primary colors: red, green and blue.
  * Similarities between the eyes and the pineal gland  
    * [Pineal Gland's Anathomy](http://www.innerbody.com/image_nerv02/nerv64-new.html#full-description)  
      Despite being a gland, the pineal gland’s histology closely resembles the structure of nervous tissue, consisting mostly of astrocytes and pinealocytes surrounded by a layer of pia mater. Pia mater is the innermost layer of the meninges that covers the brain and spinal cord. It is made of a thin layer of fibrous connective tissue and contains many blood vessels that support the underlying tissues. Astrocytes are a type of neuroglia found in the central nervous system that support and protect neurons, but in the pineal gland they support the pinealocytes. Found only in the pineal gland, pinealoctyes are unique secretory cells that produce and secrete the hormone melatonin.  
    * [Descartes and the Pineal Gland](http://plato.stanford.edu/entries/pineal-gland/)  
      The pineal gland is a tiny organ in the center of the brain that played an important role in Descartes' philosophy. He regarded it as the principal seat of the soul and the place in which all our thoughts are formed. In this entry, we discuss Descartes' views concerning the pineal gland.  
    * [MIT's Pineal Gland description](http://web.mit.edu/dick/www/pdf/40.pdf)  
    > the pineal is not a gland in the traditional sense but is a fourth neuroendocrine transducer; it is a gland that converts a nervous input into a hormonal output.  
    > In the 17th century Ren6 Descartes embellished this notion; he believed that the pineal housed the seat of the rational soul. In his formulation the eyes perceived the events of the real world and transmitted what they saw to the pineal by way of "strings" in the brain [see illustration below]. The pineal responded by allowing humors to pass down hollow tubes to the muscles, where they produced the appropriate responses. With the hindsight of 300 years of scientific development, we can admire this prophetic formulation of the pineal as a neuroendocrine transducer!  
    > delayed sexual development in children with true pineal tumors was a consequence of increased pineal activity.  
    > After puberty the human pineal is hardened by calcification; this change in the appearance of the pineal led many investigators to assume that the organ xwas without function and further served to discourage research in the field. (Actually calcification appears to be unrelated to the pineal functions we have measured.)  
    > He (Nils Holmgren) was surprised to find that the pineal contained distinct sensory cells; they bore a marked resemblance to the cone cells of the retina and were in contact with nerve cells. On the basis of these obser-
vations he suggested that the pineal might function as a photoreceptor, or "third eye," in cold-blooded vertebrates.
In the past five years this hypothesis has finally been confirmed by electrophysiological studies: Eberhardt Dodt and
his colleagues in Germany have shotwn that the frog pineal is a wavelength discriminator: it converts light energy of
certain wavelengths into nervous impulses.  
    > Extensive studies of a variety of mammalian species have confirmed this original observation that only the pineal appears to have the ability to synthesize melatonin. (In amphibians and some birds small amounts of melatonin are also manufactured by the brain and the eye.) Other investigators have found that the pineal contains all the biochemical machinery needed to make melatonin from an amino acid precursor, 5-hydroxytryptophan, which it obtains from the bloodstream. It was also found that circulating melatonin is rapidly metabolized in the liver to form 6-hydroxymelatonin.  
    > He demonstrated clearly that although this organ (rat pineal) originates in the brain in the development of the embryo, it loses all nerve connections with the brain soon after birth.  
    > Meanwhile electron microscope studies by other workers on the pineal regions of frogs had confirmed many of Holmgren's speculations. It was found that the pineal cells of amphibians contained light-sensitive elements that were
practically indistinguishable from those found in the cone cells of the retina, but that the pineal cells of mammals did not contain such elements.  
    > Even though the mammalian pineal no longer seemed to respond directly to light, there now appeared good evidence that its function continued to be related somehow to environmental light.  
    > How was information about the state of lighting being transmitted to the rat pineal? Three possible routes suggested themselves. The first was that light penetrated the skull and acted directly on the pineal; W. F. Ganong and his colleagues at the University of California at Berkeley had already shown that significant quantities of light do penetrate the skulls of mammals. This hypothesis was ruled out, however, by demonstrating that blinded rats completely lost the capacity to respond to light with changed HIOMT activity; hence light had to be perceived first by the retina and was not acting directly on the pineal.  
The second possibility was that light altered the level of a circulating hormone, perhaps by affecting the pituitary gland, and that this hormone secondarily influenced enzyme activity in the pineal gland. This hypothesis was also ruled out by demonstrating that the removal of various endocrine organs, including the pituitary and the ovaries, did not interfere with the response of pineal HIONIT to light.  
The third possibility was that information about lighting was transmitted to the pineal by nerves. Fortunately Arisns Kappers had just identified the nerve connections of the rat pineal as coming from the sympathetic nervous system. We found that if the sympathetic pathway to the pineal was interrupted by the removal of the superior cervical ganglion, the ability of melatonin-forming activity to be altered by light was completely lost. Thus it appeared that light was stimulating the retina and then information about this light was being transmitted to the pineal via sympathetic nerves.  Within the pineal the sympathetic nerves probably released neurohumors (noradrenaline or serotonin), which acted on pineal cells to induce (or block the induction of) HIONIT; this enzyme in turn regulated the synthesis of melatonin.  
    > It was found that interrupting the transmission of light information to the pineal (by cutting its sympathetic
nerves-a procedure that does not interfere with the visual response to light) also abolished most of the gonadal response to light  
    > When rats are blinded or when the sympathetic nerves to the pineal are cut, the effect of light and darkness on the serotonin-forming enzyme is also extinguished.  
  * How animals see?  
    * [Human and Animal Vision](http://link.springer.com/referenceworkentry/10.1007%2F978-1-84996-169-1_3)  
    > The natural world has produced many different models for vision. For example, there are over 40 different types of eye. The compound eye of the insects and our own eye are obviously very different. Even the eye of a relatively close relation, the cat, is significantly different from our own, having a vertical pupil in bright light. Some animal eyes move the lens to focus on objects that are moving along the line of sight, rather than alter the shape of the lens, as our own eyes do. There is nothing particularly special about our colour vision either. Mantis shrimps, for example, have 12 different colour pigments in their eyes. Spiders are not content with just two eyes as we are; they have eight!  
    * [Could humans see like animals? - Earth Juice (Ep 48)](https://www.youtube.com/watch?list=SPtra-MWzIvZF6mUIzJLvzxtFoYj41Yaly&v=O1-js0k2rBE)
  * How animals hear?  
    * [Frequency of Bat Sonar](http://hypertextbook.com/facts/1998/JuanCancel.shtml)  
    * [How Well Do Dogs and Other Animals Hear?](http://www.lsu.edu/deafness/HearingRange.html)  
  * Natural acoustic amplifiers  

* Fast Fourier Transformation (FFT)
  * [OpenCL](https://en.wikipedia.org/wiki/OpenCL) - Open Computing Language (OpenCL) is a framework for writing programs that execute across heterogeneous platforms consisting of central processing units (CPUs), graphics processing units (GPUs), digital signal processors (DSPs), field-programmable gate arrays (FPGAs) and other processors or hardware accelerators.  
  * [OpenMP](https://en.wikipedia.org/wiki/OpenMP) - OpenMP (Open Multi-Processing) is an application programming interface (API) that supports multi-platform shared memory multiprocessing programming in C, C++, and Fortran,[3] on most platforms, processor architectures and operating systems, including Solaris, AIX, HP-UX, Linux, OS X, and Windows. It consists of a set of compiler directives, library routines, and environment variables that influence run-time behavior.  
  * [OpenACC](https://en.wikipedia.org/wiki/OpenACC) - OpenACC (for Open Accelerators) is a programming standard for parallel computing developed by Cray, CAPS, Nvidia and PGI. The standard is designed to simplify parallel programming of heterogeneous CPU/GPU systems.
  Like in OpenMP, the programmer can annotate C, C++ and Fortran source code to identify the areas that should be accelerated using compiler directives and additional functions.[2] Like OpenMP 4.0 and newer, code can be started on both the CPU and GPU.   
  * [FFTW API](http://fftw.org/) - FFTW is a C subroutine library for computing the discrete Fourier transform (DFT) in one or more dimensions, of arbitrary input size, and of both real and complex data (as well as of even/odd data, i.e. the discrete cosine/sine transforms or DCT/DST).      
  * [cuFFT](https://developer.nvidia.com/cufft) - uses cufftComplex structure as input, so data can be 32-bit or 64-bit floating point array. As a promotion nVidia offers free access to NVIDIA TESLA K40 GPUs.  
  * [clFFT](https://clmathlibraries.github.io/clFFT/) - clFFT is a software library containing FFT functions written in OpenCL. In addition to GPU devices, the library also supports running on CPU devices to facilitate debugging and heterogeneous programming.  

* Data and File Formats
  * [RIFF WAVE](https://en.wikipedia.org/wiki/WAV) [LPCM](https://wiki.multimedia.cx/?title=PCM) - uncompressed, max 65536 channels, max 4.295Ghz frequency, limited to 4GB in size, formats: 8-bit unsigned int, 16-bit signed int, [32-bit signed float](http://stackoverflow.com/questions/2062620/how-to-write-wav-file-with-32-bit-float-data#2075263), 64-bit signed float
  * [BWF](https://en.wikipedia.org/wiki/Broadcast_Wave_Format)/[RF64](https://en.wikipedia.org/wiki/RF64) - like WAVE, but without the 4GB size limit
  * [EDF](http://www.edfplus.info/specs/edf.html), [EDF+](http://www.edfplus.info/specs/edfplus.html), [BDF](http://www.biosemi.com/faq/file_format.htm) and [BDF+](http://www.teuniz.net/edfbrowser/bdfplus%20format%20description.html) - BDF+ is the 24-bits version of EDF+. EDF+ is the popular medical time series storage fileformat.  
EDF+ stores digital samples (mostly from an analog to digital converter) in two bytes, so the maximum
resolution is 16 bit. However, 24-bit ADC's are becoming more and more popular. The data produced
by 24-bit ADC's can not be stored in EDF+ without losing information.  
BDF+ stores the datasamples in three bytes, giving it a resolution of 24 bit.
  * [ASIO](https://en.wikipedia.org/wiki/Audio_Stream_Input/Output) - Audio Stream Input/Output (ASIO) is a computer sound card driver protocol for digital audio specified by Steinberg, providing a low-latency and high fidelity interface between a software application and a computer's sound card. Whereas Microsoft's DirectSound is commonly used as an intermediary signal path for non-professional users, ASIO allows musicians and sound engineers to access external hardware directly.
  * [Gerbil](http://www.gerbilvis.org/doc/formats/) - The main concept behind Gerbil's file format is ease-of-use without duplication of present data. The hyperspectral cube is represented by an array of intensity images, each describing one spectral band. A human-readable descriptor file then provides the meta information necessary to construct the image from these intensity files. (e.g. list of grayscale PNGs, the frequency ranges defined for each)

# Reading material

## Books
  * [The Heart's Code](https://www.amazon.com/Hearts-Code-Paul-P-Pearsall-ebook/dp/B000FC1IIG) (March 10, 1999) - 4.3 (75) - $14
  * [Electrodynamic Man](http://www.amazon.com/Electrodynamic-Man-Leonard-J-Ravitz/dp/158244210X/) (August 1, 2002) - 4.6 (5) - $57
  * The soul of the body: Auradynamics (2015) - $13
  * [Consciousness Beyond the Body](https://www.amazon.com/Consciousness-Beyond-Body-Evidence-Reflections-ebook/dp/B01BM1SMS2) (February 9, 2016) - 4.8 (10) - $1
  * [Beyond Biocentrism](https://www.amazon.com/Beyond-Biocentrism-Rethinking-Consciousness-Illusion-ebook/dp/B01B11TQMO) (May 3, 2016) - 4.1 (109) - $13
  * [Astronomical Spectroscopy for Amateurs](https://www.amazon.com/dp/B00F5TLPHI) (February 7, 2011) - 5.0 (7) - $19
  * [The Man Who Tapped the Secrets of the Universe](https://www.amazon.com/Man-Who-Tapped-Secrets-Universe-ebook/dp/B00CD7X1JK/) (April 14, 2013) - 4.6 (48) - $6  
  * [Working Effectively with Legacy Code](https://www.amazon.com/Working-Effectively-Legacy-Robert-Martin-ebook/dp/B005OYHF0A) (September 22, 2004) - 4.6 (107) - $41  
  * [Energy Medicine: The Scientific Basis](https://www.amazon.com/Energy-Medicine-Scientific-James-Oschman-ebook/dp/B018UF88AU) (September 4, 2015) - 4.2 (17) - $47  
  * [PEMF - The Fifth Element of Health](https://www.amazon.com/PEMF-Element-Electromagnetic-Therapy-Supercharges-ebook/dp/B00EU19OSE) (August 19, 2013) - 4.5 (168) - $3  
  * [Healing is Voltage: The Handbook](https://www.amazon.com/Healing-Voltage-Handbook-Jerry-Tennant-ebook/dp/B00JS6HK46/) (April 17, 2014) - 4.6 (173) - $15  
  * [AURAS: How to See, Feel & Know](https://www.amazon.com/AURAS-Feel-Know-Full-Color-ebook/dp/B0095ZIXZK) (September 4, 2012) - 4.4 (151) - $6  

## Researchers
  * F. K. Bellokossy  
    * Book: [Homeopathy Explained](https://www.amazon.com/Homeopathy-Explained-reprint-September-Homeopathic/dp/B000KE1U3M) (1969)
  * Royal Raymond Rife (1888-1971)  
  * W. Ross Adey (1922-2004)  
  * Suzanne Bawin  
    * Book: [Self-Organized Biological Dynamics and Nonlinear Control](https://www.cambridge.org/core/books/self-organized-biological-dynamics-and-nonlinear-control/EA3776C26BA4ABEDC43A3A04A1F5FC0E#) (2000) - 41 GBP
  * Mae-Wan Ho (1941-2016)  
    * [Living Rainbow H2O](https://www.amazon.com/Living-Rainbow-H2O-Mae-Wan-Ho/dp/9814390895/) (August 21, 2012) - $38
  * [William C. Nelson](http://www.quantumcentre.com/footer-pages.php?page_id=37) (1951-)
    * Articles between [2013 and 2016](https://academic.microsoft.com/#/search?iq=Composite(AA.AuN%253D%253D'william%2520c%2520nelson')&q=william%20c%20nelson&filters=Composite(AA.AuId%3D2167705691)%2CY%3E%3D2013&from=0&sort=0)
  * Paul J. Rosch
    * Book: [Bioelectromagnetic and Subtle Energy Medicine, Second Edition](https://www.amazon.com/Bioelectromagnetic-Subtle-Energy-Medicine-Second-ebook/dp/B00S9OM5MU) (December 19, 2014) - $220
  * James L. Oschman
    * Book: [Energy Medicine: The Scientific Basis](https://www.amazon.com/Energy-Medicine-Scientific-James-Oschman-ebook/dp/B018UF88AU) (September 4, 2015) - $48
  * [Marko S. Markov](https://www.linkedin.com/in/marko-markov-60315511)  
    * Book: [Electromagnetic Fields in Biology and Medicine](https://www.amazon.com/Electromagnetic-Fields-Biology-Medicine-Markov-ebook/dp/B00UVB2I9O/) (March 2, 2015) - $175
    * Article: ["Biological Windows": A Tribute to W. Ross Adey](http://lenyosys.com/wp-content/uploads/2015/04/Biological-windows-by-Marko-markov.pdf) (2005)  
      "Despite the difference in terms, the sense of the three papers was the same—the authors found evidence for the existence of specific amplitude or frequency values at which the response of the biological system was more pronounced than in the surrounding amplitude or frequency intervals."  
      "Discussing the theoretical feasibility of a radical-pair mechanism Eichwald and Walleczek (2000) affirmed that this model is capable of accounting for bioelectromagnetic phenomena which depend on the field frequency in a non-linear, resonance-like fashion (frequency window), field amplitude (amplitude window), the combination of appropriate AC and DC magnetic fields, and the biodynamic state of the field exposed system."  
      "In a series of experiments designed to study a large range of magnetic flux density (up to 100 mT) static magnetic fields applied to biosystems with different levels of organization (microorganisms, plants, and animals) a specific maximum of the observed bioeffects was found when the magnetic flux density was 45 mT (Markov, 1991, 1989)."  
      "Probably the most systematic study of the 10–20 mT range of static magnetic fields was done by Zukov (1999) who wrote 'In general, within the range of 10–15 mT the therapeutic effect of magnetic fields is expressed to the greatest degree which made it unnecessary to try to generate high levels of magnetic field induction'."  
      "It has been reconfirmed recently that the calmodulin is the most important Ca2+ receptor (Liboff et al., 2003)"  
      "It should be noted that calcium ions appear to be essential in the first steps of transductive coupling of exogenous physical signals to biological tissues and in the ensuing steps of calcium-dependent signaling to intracellular enzyme systems (Bull et al., 1993)."  
      "Figure 1 represents the systematic analysis of myosin phosphorylation in response to applied static magnetic fields in the range of 5–55 mT." ... "It is seen that for all exposure conditions the values of myosin phosphorylation are significantly higher than the control. Two sharp maximums at 15 mT and 45 mT were clearly present."  
      "Figure 2 shows the myosin phosphorylation data collected when the reaction mixture was exposed to TEMF (120Hz pulsating magnetic field) in the range of 5–25 mT." ... "It is evident that under these experimental conditions the 15 mT sharp maximum is also present."  
      "Studying the in vivo response of blood coagulation and anticoagulation system Markov and Todorov (1984) found out that from 10 different by amplitude magnetic fields, the maximal response was received at 15 mT AC (50 Hz) field for fibrinogen level and at 45 mT DC field for prothrombin time."  
      "It is known now that EMF are more effective for systems out of equilibrium (due to disease or injury). It is also known that, for example, when fracture or wound appeared, an injury current originates. The best compensation for this current is electromagnetic compensation achieved by various low frequency (for fracture) and high frequency (for soft tissue injuries) devices."  
  * Leonard J. Ravitz
    * Book: [Electrodynamic Man](https://www.amazon.com/Electrodynamic-Man-Leonard-J-Ravitz/dp/158244210X/) (August 1, 2002) - $57
  * Robert O. Becker
    * Book: [The Body Electric: Electromagnetism And The Foundation Of Life](https://www.amazon.com/Body-Electric-Electromagnetism-Foundation-Life/dp/0688069711/) (July 22, 1998) - $10  
    * Book: [Electromagnetism and Life](https://www.amazon.com/Electromagnetism-Life-Robert-O-Becker/dp/0981854907) (April 6, 2010) - $32
  * Valéria Szedlák-Vadócz (1946-)
  * Bryant A, Meyers
    * Book: [PEMF - The Fifth Element of Health: Learn Why Pulsed Electromagnetic Field (PEMF) Therapy Supercharges Your Health Like Nothing Else!](https://www.amazon.com/PEMF-Element-Electromagnetic-Therapy-Supercharges-ebook/dp/B00EU19OSE) (August 19, 2013) - $3
    * Interview: [Brian Tracy Show - PEMF Therapy w/ Bryant Meyers](https://www.youtube.com/watch?v=ZFaIV2RW3aE)

## Research Paper Sources
  * [Microsoft Academic Search](https://academic.microsoft.com)

Quotes
------

## Robert Lanza - Beyond Biocentrism: Rethinking Time, Space, Consciousness, and the Illusion of Death

## James L. Oschman - Energy Medicine: The Scientific Basis

> We now know that many of the most common health disorders and diseases are partly or entirely energetic in nature and are therefore difficult to prevent or treat when energy is left out of the equations of life and healing.

> This growing body of research can be summarized with the statement that many and perhaps all of the chronic diseases and disorders that plague modern society, and that are the most costly in terms of money and human suffering, have a common cause, and that cause is best described in terms of energetics.

> One of the most exciting areas of energy medicine is the field known as energy psychology. Those who suffer from emotional trauma and abuse can be just as debilitated as those who have a chronic disease or physical injury.

> We shall see that measurements of the biofields around the human body are now being used in Western medical diagnosis to make treatment decisions. We are also beginning to understand the biophysical mechanisms that enable both complementary therapists and conventional physicians to detect and manipulate energy fields for the benefit of the patient. Below the level of measurable energetic interactions lies an area known as subtle energies. These are energies that we know must be present because of observable clinical effects, even though no energy can be measured with conventional instruments. Quantum physics is helping us understand the nature of the physical forces that underlie electricity, magnetism, and electromagnetism. This is actually what quantum physics is all about. We now know, for example, that what we refer to as matter is a phenomenon that arises from subtle quantum processes.

> Energetics is a rich multi-disciplinary topic. Following the flows of energy through the body is a lesson in every domain of science, ranging from cosmological and geophysical to inter-organism interactions (the ecological level) to physiology, biochemistry, molecular biology, pathology, and behaviour, as well as organs, tissues, cells, molecules, atoms, subatomic particles, and the space between all of the parts. Energetics provides a rich and fascinating and exciting perspective for exploration.

> Energy medicine involves the use energies of particular intensities and frequencies and other characteristics that stimulate the repair of one or more tissues, or that enable built-in healing mechanisms to operate more effectively. Such energies can come from the environment, from another human being or from a medical device.

> We shall see that when a charge moves, magnetic fields are produced. And we will also see that the opposite is true: Magnetic fields alter the motions of nearby charges.

> The strongest electrical field is produced by the heart and generates a current that flows through the circulatory system, which is a good conductor.

> All objects in the universe, from the very smallest to the very largest, are continuously vibrating. Since matter is composed of charged particles such as electrons and protons, all vibrating matter is emitting electromagnetic fields.

> Very weak energy fields at the appropriate frequencies can be profoundly therapeutic.

> While it may go against intuition, it appears that, within limits, it is not the strength of the signal that determines whether it will be beneficial or harmful, but instead it is the frequency. Resonance is the reason for this frequency specificity. Biological effects, like molecular resonances, are very frequency specific.

> Electromagnetic resonance can be used to influence processes taking place in areas that are difficult to reach with drugs, such as the interior of the brain, which is protected by the blood–brain barrier, or the interior of pockets of inflammation that are separated from the general circulation by an inflammatory barricade,

> Molecules can behave as resonant antennas, meaning that they can radiate and absorb electromagnetic fields.

> His set of equations – Maxwell’s equations – demonstrated that electricity, magnetism, and light are all manifestations of the same phenomenon: the electromagnetic field. Maxwell demonstrated that electric and magnetic fields travel through space in the form of waves.

> Living tissues have both of these properties, inductance and capacitance. LC circuits are used for generating signals at particular frequencies or for picking out a signal at a particular frequency from a more complex signal.

> Metallic wires are good antennas, and many molecules, including DNA, are referred to as molecular wires, and are therefore good antennas as well.

> In a series of studies, Phillip Callahan demonstrated that the pheromone molecules are actually molecular antennas that emit radio signals. The male moth looking for the female is not attracted by the scent or smell of the pheromones, but by the radio signals the molecules emit.

> Not only does every event in the body, either normal or pathological, produce electrical changes, it also produces alterations of the biomagnetic fields in the spaces around the body.

> Specifically, viral and bacterial infections, as well as cancer, affect the ionic and water content and pH of the extracellular fluids and thereby affect the cell membrane potentials and tissue conductances.

> Another effect of electric fields is the enhancement of ATP production in the cells involved in the repair process. This is important because energy from ATP is needed to power cell migrations and the synthesis of new proteins and other molecules that must be replaced. This was demonstrated by Cheng et al. (1982), who found that currents of 10–1000 μA produced a three- to five-fold increase in ATP levels. Higher current levels, into the milliampere range, decreased protein synthesis.

> The method involves applying square-wave pulses to the skin and observing the current waveforms with an oscilloscope (Lykken, 1971). The skin’s electronic properties during healing changed little during the first 3–4 days, then the skin potential recovered suddenly.

> Treating pain by reducing inflammation is supported by the vast amount of research on the role of inflammation in chronic disease and by the hypothesis presented in a paper by Sota Omoigui (2007) entitled ‘The biochemical origin of pain – proposing a new law of pain: The origin of all pain is inflammation and the inflammatory response.

> At a fundamental level, we still do not know exactly what electricity and magnetism really are. The electron is a basic unit of matter and has properties such as charge, mass, spin, and gravity, but a deeper explanation of how these properties arise is missing.

> Specifically, the heart produces a mixture of pulses of electricity, magnetism, sound, heat, vibration, and light that are transmitted to every part of the body via the circulatory system and extracellular fluids and thereby reach every cell in the body (see Figure 15.6). These signals may serve a variety of vital regulatory roles.

> A discovery in quantum physics led to the development of instruments that can map the energy fields of the human body with unprecedented sensitivity and accuracy. For example, there are devices that can pick up the field of the heart 15 feet away from the body.

> It turns out that biomagnetic fields are often better indicators of events taking place within the body than are electrical measurements at the skin surface. For example, biomagnetic fields produced by the brain pass undistorted through the cerebrospinal fluid, across the connective tissue covering of the brain (the dura), and through the skull bones and scalp. These tissues are virtually transparent to magnetic fields. In contrast, the electrical signals recorded with the electroencephalogram become distorted, smeared, and decreased in strength by a factor of about 10,000 as they pass through the surrounding tissues. EEGs therefore do not give as precise a representation of brain activity as MEGs. Electrical measurements are also compromised by intricate interactions between the skin and the electrode pickups, which can act as batteries and generate currents on their own. All in all, the MEG appears to provide more detail and better spatial localization than the EEG. The same advantages pertain to the magnetocardiogram.

> Every muscle in the body produces magnetic pulses when it contracts.

> The fields of all of the organs spread throughout the body and into the space around it.

> From the research done over the last few decades, we can definitely conclude that: ■ Living organisms have biomagnetic fields around them. ■ These fields change from moment to moment in relation to events taking place inside the body. ■ The information contained in the biomagnetic fields give a more detailed representation of what is going on in the body than classical electrical diagnostic tools such as the electrocardiogram and the electroencephalogram. ■ It can reasonably be hypothesized that the biofield is used as a fast communication system, assisting in integrating the body’s diverse functions, although there is no objective evidence for this. This should not be taken to suggest that the ‘fields of life’ are entirely magnetic. Other kinds of fields are also present (see Chapter 1).

> There is an old idea that our technology recapitulates our biology – that all of our technological devices were first invented and perfected during millions of years of evolutionary experimentation with the laws and energies of nature. Perhaps there is a magnetic sense in the human body, a sense that can be developed and used in healing.

> Living cells amplify extremely weak electromagnetic fields and separate signals from large amounts of ambient noise.

> Pall (2013) summarized 23 studies demonstrating that voltage-gated calcium channels, which regulate a vast number of cellular processes, are activated virtually instantaneously by very weak photons. Pall’s study marks a turning-point in “frequency medicine” involving the application of low-energy oscillating fields from medical devices, essential oils, botanical and homeopathic remedies, pharmaceuticals, the voice, and the human hand.

> There is a way for regulatory molecules to communicate without touching. Every object has a certain natural or resonant frequency. Strike it, bump it, pluck it, or heat it and it will tend to vibrate at a specific frequency. This applies to a bone, a piece of wood, a molecule, an atom, an electron, or a string on a musical instrument.

> Not only does each vibrating molecule emit a characteristic set of electromagnetic frequencies, similar molecules a distance away will also absorb the same frequency from their environment. Such absorptions can be measured to provide an absorption spectrum. What is important for regulatory communications within an organism is that similarly shaped molecules will resonate with each other. The mechanical or musical analogy to this is called the tuning fork effect.

> Spectrometers of various kinds are used to measure the emissions and absorptions of molecules. Technically the radiation or absorption pattern is called a spectrum (a graph of energy intensity versus frequency or wavelength).

> The spectrum is an electromagnetic ‘signature’ or ‘fingerprint’ of a molecule that is an extremely precise representation of the motions of the particles within it.

> In terms of vibrations, the human body can be compared to a symphony orchestra. Each molecule corresponds to a particular instrument. Each bend, rotation, or stretch of a chemical bond has a certain resonant frequency and will give off certain frequencies or ‘notes’ if it is energized. Since molecules, water, and dissolved ions are constantly bumping into each other at body temperature (Figure 9.2), all parts are constantly jiggling and absorbing and emitting characteristic frequencies.

> A soprano shatters a crystal goblet by singing a high note coinciding with the natural frequency of the goblet. The atoms in the glass vibrate so strongly that they cannot hold together, and the goblet breaks. The same thing can happen to a molecule.

> Molecules are composed of atoms, which are made up of electrons. Virtually all of our knowledge about molecules, and about matter in general, has come from studying the ways light interacts with electrons. 

> The tendency to retain the definitions of terms that were acceptable in early stages of a study or science is called meaning invariance. It creates very serious logical problems over time because a re-examination of a certain meaning could require revision of widely accepted concepts.

> Some philosophers who explore the methods of science recognize that virtually all scientific discoveries are based on assumptions or approximations of one kind or another and that scientific truth is therefore always relative or approximate

> Hence, communication in living systems involves two main languages: chemical and energetic. Chemical regulations are carried out by hormones, various ‘factors’ (e.g., growth factor, epithelial growth factor) and the various ‘second messengers’ within cells. In contrast, energetic interactions are of two kinds, electrical and electronic. The electrical activities of nerves and muscles are well known, but there are many other kinds of energetic signaling systems. Some remain to be discovered. We shall see that an even more profound realization is emerging. The entire living matrix is simultaneously a mechanical, vibrational or oscillatory, energetic, electronic, photonic and informational network

> For example, certain kinds of crystals are piezoelectric, that is, they generate electric fields when they are compressed or stretched. Many piezoelectric materials are also thermoelectric – they generate electric fields when their temperature changes.

> The matrix is the locus of the pathways that allow cells to communicate with each other. Any interference or blockage in these pathways can set the stage for disease. Toxins can accumulate in the matrix and can impact functioning. Here Pischinger is in complete agreement with A.T. Still: Most effective therapeutic approaches restore or enhance signaling and energy flows in the matrix and thereby prevent or treat disease.

> The concept of semiconduction in living systems was vigorously opposed, but it was eventually shown to be entirely correct (Rosenberg and Postow, 1969). Virtually all of the molecules forming the living matrix are semiconductors.

> The perineural system is a distinct communication system. It sets up a low voltage current, the current of injury that controls injury repair. Pulsations of the direct current field in the brain, the so-called brain waves, direct the overall operation of the nervous system, and may regulate consciousness.

> One of Becker’s important discoveries is that the perineural system is sensitive to magnetic fields.

> Becker concluded that the acupuncture points and meridians are input channels for the system that regulates tissue repair. With Maria Reichmanis, Becker showed that the meridians are low-resistance pathways through the body.

> Each molecule, cell, tissue, and organ has an ideal resonant frequency that coordinates its activities. By manipulating and balancing the vibratory circuits, complementary therapists are able to directly influence the body’s systemic defence and repair mechanisms.

> Cells and intracellular elements are capable of vibrating in a dynamic manner with complex harmonics, the frequency of which can now be measured and analyzed in a quantitative manner by Fourier analysis (and by other methods). Cellular events such as changes in shape, membrane ruffling, motility, and signal transduction occur within spatial and temporal harmonics that have potential regulatory importance. These vibrations can be altered by growth factors and the process of carcinogenesis. It is important to understand the mechanism by which this vibrational information is transferred directly throughout the cell [and throughout the organism].

> While much research has been done on this subject, we still do not know the source of the plan that enables the body to grow into its adult form and that restores tissues to normal after injury or disease.

> we begin with a summary of what these rules are not and the reasons we know this: 1. DNA is not the blueprint of the organism. 2. Ontogeny (morphogenesis or the developmental history of an organism) does not recapitulate (repeat) phylogeny (the evolutionary history of a species). 3. The growth of an organism is not brought about by a set of linear cause and effect events like the construction of an automobile on an assembly line. 4. It is no longer believed that differentiation is a one-way street, that once a cell has been ‘committed’ to become, say, an intestinal cell, it cannot revert to the undifferentiated state. 5. The organism does not, in fact, develop.

> Genes are undoubtedly involved at every step of development, but this does not mean they deserve all of the credit for establishing structures and functions at every level of scale.

> In contrast to the automobile that wears out, the body always has the possibility of regenerating and even improving its structural and functional integration. To see this process in action, watch an athlete or other performer practicing.

> Wound healing and recovery from disease are among the most important and remarkable of living processes, involving the integrated and cooperative activities of many regulatory systems throughout the body. Level upon level of intricate control systems and feedback loops join together to accelerate and inhibit myriad activities, on a moment-to-moment basis. Even the smallest pin-prick alters the behaviour of millions of cells, billions of molecules, trillions of atoms, and untold numbers of subatomic particles. While biology and medicine are aware of some aspects of this continuum, what is truly remarkable is that ‘hands-on’ therapists are able to interact with all of it in profoundly significant ways that await thorough scientific investigation. Often intuition and intention guide the hands, without analysis of the details.

> Albert Einstein stated that, ‘If at first the idea is not absurd, then there is no hope for it’.

> Becker has shown that very low levels of electrical stimulation can cause cultures of so-called differentiated cells to de-differentiate into totipotent cells capable of forming all of the tissues needed to replace a lost or damaged part. His fascinating description of this breakthrough research can be found in his book (Becker and Sheldon, 1985). The key to Becker’s demonstration was reducing the strength of electrical stimulation. Following the usual way scientists tend to look at such matters, he assumed a large current would be more effective than a small one. The opposite was correct.

> Biomedicine continues to emphasize the most difficult, painful, and expensive methods, such as artificial organs and organ transplants, instead of examining the more natural approach of regeneration: …all of the circuitry and machinery is there; the problem is simply to discover how to turn on the right switches to activate the process.

> A signal generator a distance from the patient is used to find the frequency that will trigger the allergic reaction. Then other frequencies are tested to find the neutralizing frequencies that stop the reaction. Signals at these frequencies can ‘potentize’ vials of water that can be carried by the patient and used to stop the reaction. The allergic response is inhibited by holding the vial of water in the hand. In a given patient, the symptoms provoked electrically are similar to those provoked chemically and those provoked by the patient’s environment. Electrical and chemical stimuli and neutralization appear to be interchangeable (Choy et al., 1987; Smith and Best, 1989).

> It is also easy to see how specific frequencies produced by vibrations of the molecules in essential oils could interact with the key components of this signalling system to produce specific effects.

> Because of Larmor precession and quantum coherence, frequency becomes a more important parameter than intensity in terms of extremely weak field effects and the establishment of regulatory standards for limiting exposures.

> In the case of aromatherapy, measurements of the frequencies of the oils are made during the manufacturing process to ensure their purity and content. These measurements can be used to determine the specific frequencies emitted or absorbed by the essential oils. This last statement should be noted because we can hypothesize that some therapeutic benefits may arise from the ability of an essential oil to absorb harmful frequencies caused by pathological processes taking place within the body. This is a good topic for future research

> Biomagnetism and bioelectricity refer to measurable magnetic and electric fields generated by a living organism; magnetobiology and electrobiology refer to the measurable effects of magnetic or electric fields on living things.

> Hence very low levels of energy coming from the hands of a therapist or an energy medicine device or a cell telephone tower or other wireless technology or a toxic chemical in the environment (see the section on allergies in Chapter 16) can have profound effects on cell and tissue functions. These sensitivities enable us to benefit from very subtle inputs from a therapist or therapeutic device or an essential oil (Chapter 17); and, tragically, the same sensitivities cause some people to be disturbed and even made very ill by wireless technologies and electrical appliances.

## Bryant A. Meyers - PEMF - The Fifth Element of Health

## Konstantin Korotkov - The Energy of Consciousness 

## Leonard J. Ravitz - Electrodynamic Man