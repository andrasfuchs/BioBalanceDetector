Mercury-16 will be a software-hardware combination to provide an 16-channel bio-potential reading.  
If this prototype proves to be useful its extension to more channels would be fairly straightforward, so we could finally get closer to the Flat Detector Panel (FDP) implementation.
This prototype will be implemented with Atmel's Xplained Kits. This allows us to make the development less painful and pave the road for the Mercury-64, which is going to have ATxmegas with its own PCB.

# Hardware Components
1x [Atmel-ICE programmer and debugger](http://www.digikey.com/product-detail/en/atmel/ATATMEL-ICE/ATATMEL-ICE-ND/4753379)  
3x [ATxmega256A3BU Xplained Kit](http://www.digikey.com/product-search/en?keywords=%20ATxmega256A3BU%20Xplained%20Kit)  
4x [15cm long, 2x5 colored ribbon cables with IDC connectors with gold contact finish](http://www.digikey.com/product-search/en/cable-assemblies/rectangular-cable-assemblies/1573018?k=&pkeyword=&pv77=2314&FV=14101b%2C1411a8%2C700642%2C780001%2C940313%2C160000a%2C1680002%2C10840002%2C1f140000%2Cfff40018%2Cfff8009a&mnonly=0&newproducts=0&ColumnSort=1000011&page=1&quantity=0&ptm=0&fid=0&pageSize=25)  
2x [91cm long, 2x5 colored ribbon cables with IDC connectors with gold contact finish](http://www.digikey.com/product-search/en/cable-assemblies/rectangular-cable-assemblies/1573018?k=&pkeyword=&pv77=2426&FV=14101b%2C1411a8%2C700642%2C780001%2C940313%2C160000a%2C1680002%2C10840002%2C1f140000%2Cfff40018%2Cfff8009a&mnonly=0&newproducts=0&ColumnSort=1000011&page=1&quantity=0&ptm=0&fid=0&pageSize=25)  
1x [Mini breadboard](http://www.digikey.com/product-detail/en/seeed-technology-co-ltd/319030008/1597-1268-ND/5488152)  
6x [2x5 pin header](http://www.digikey.com/product-detail/en/sullins-connector-solutions/PRPC005DABN-RC/S2021EC-05-ND/2775941)  
1x [65 jumper wire kit](http://www.digikey.com/product-detail/en/bud-industries/BC-32625/377-2093-ND/4156446)  
3x [A male to mini B male USB cable](http://www.digikey.com/product-detail/en/assmann-wsw-components/AK672M-2-1/AE1450-ND/930235)

![Atmel-ICE](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto05/IMG_20161221_140506_Atmel-ICE.jpg)

![Atmel XMEGA-A3BU Xplained](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto05/IMG_20161221_140511_XMEGA-A3BU_Xplained.jpg)

![3 Atmel XMEGA-A3BU Xplained Kits](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto05/IMG_20170813_140519_3_Kits.jpg)

## Costs

### Development costs: $255 + $1 postage + $24 [import tax](http://igtf.customs.go.th/igtf/en/main_frame.jsp) (10%) + $18 VAT (7%)    

#### New Equipment: $134  
 * $134 - 1x ATATMEL-ICE ([Tariff Code](https://en.wikipedia.org/wiki/Tariff): 8471.50.0150 -> 40%-20%([WTO](https://en.wikipedia.org/wiki/World_Trade_Organization)-10%) import tax)  

#### New Materials: $121  
 * $ 94 - 3x ATXMEGAA3BU-XPLD (Tariff Code: 8471.41.0150 -> 40%-20%(WTO)-10% import tax)  
 * $  5 - 4x H3CCH-1006M (Tariff Code: 8544.42.9090)  
 * $  5 - 2x H3CCH-1036M (Tariff Code: 8544.42.9090)  
 * $  3 - 1x 1597-1268 (Tariff Code: 8537.10.9150)  
 * $  3 - 6x S2021EC-05 (Tariff Code: 8536.69.4040)  
 * $  5 - 1x 377-2093 (Tariff Code: 8544.49.3080)  
 * $  7 - 3x AE1450 (Tariff Code: 8544.42.9090)  

#### Fabrication: $0  
  
### Net cost per unit

### Order(s)
2016-12-09 [DigiKey #48722567](http://www.digikey.com/short/35b57w) - Order Placed  
2016-12-10 [DigiKey #48722567](http://www.digikey.com/short/35b57w) - Dispatched [USPS Tracking #EC577797721US](https://tools.usps.com/go/TrackConfirmAction_input?qtc_tLabels1=EC577797721US)  
2016-12-21 [DigiKey #48722567](http://www.digikey.com/short/35b57w) - Delivered

# Architecture

All of the XMEGA kits except one is called **cell**. The cell is a sensor-hub, so its function is to collect data from multiple sensors, connected to its ADC channels. The exception is called the **organizer**, which collects the data from the cells, organizes the data and sends it through its USB interface to the PC.  
Every cell has 8 sensors and 1 emitter arranged in a 3x3 2D matrix. Cells can be daisy-chained, so the theoretical limit of cells depends only on the protocol.  
Organizer speed is critical and since XMEGAs support only USB 2.0 it will mean a serious bottleneck.  

# Bandwidth bottlenecks

We generate 12 bit/sample data, 2 megasamples/second for every sensor. Every 8 sensors will be connected to one ATxmega64A3U, and all ATxmega64A3Us will be connected trough UART to ATxmega256A3U. The ATxmega256A3U will format and forward the data trough USB to the PC. The PC will compute the FFTs of the datastreams using the available CPUs or GPUs.  

The clock speed for all the ATxmegas will be 32Mhz. If the speed is not enough, [XMEGAs can be overclocked to 64-70Mhz](http://www.avrfreaks.net/forum/atxmega-max-frequency), so it would double the speed.  

Since every sensor generates 12x2048x1024 bits of data every second, and we are planning to have at least 8 sensors per cell, the data rate on the bus should be at least 192Mbps multiplied by the number of cells. That looks enormous.  
  
On the other hand, a trick could be to compress the data what will be sent from the cell to the organizer. The 8 sensors of a cell will always be positioned close to each other, so their values will be similar in most cases. We could send the first sensors data as a 12-bit value, but after the next 7 sensors' data would be transformed to the 4-bit difference to its precursor. To compress the data even further, we could send only the sensor's value's difference from the previous one, represented with 4 bits.   
According to my real-world tests however, these compression techniques would distort the data so much, that is would not really be useful.  
Coming from the other end, let's assume, that we will use the USART's 16Mbps bus to send data from the cells to the organizer. Supposing that we will have a 15% overhead we have 13.6Mbps bandwidth to use. How many sensors can we connect to that bus at what sample rate?  
* cell count = (sensor / 8)
* organizer's USART bandwidth = 13.6Mbps  
* cell's bandwidth = organizer's bandwidth / cell count  
* sensor's bandwidth = sample rate * 12 bit  

So, we get the following:  
13.6Mbps = sensor count * sample rate * 12 bit  
sensor count = 1.13Mbps / sample rate  

The MPCM's addressing protocol also sets a limit of 256x8 = 2'048 sensors per organizer, but that's obviously higher than the speed limitation we have.    
  
Realistically the sensor density could be increased up until the 1 sensor/1 cm^2, so the total area scanned could reach 1040 cm^2, which is like a 32x32cm square.  
If we would like to increase the covered area even more we need to keep in mind that the XMEGA's USB speed is also limited to 12Mbps, so it might be more wise to use an external USB (3.1, 10Gbps) chip and send the data to that from multiple organizers.  
  
For this version though, the 2Mbps UART and the 12Mbps USB is more than enough, even if we don't compress the data on the cells.  

# Software components

### Serial Bootloader
Custom bootloader will be needed for the cells, because we want to refresh their firmware in-system, once they are installed on the board. This is a low priority now, can be postponed until Mercury-64.  
[Atmel AVR2054: Serial Bootloader User Guide](http://www.atmel.com/Images/Atmel-8390-WIRELESS-AVR2054-Serial-Bootloader-User-Guide_Application-Note.pdf), [its images and source code](https://gallery.atmel.com/Products/Details/992efa59-3d2f-44b8-aa4d-ea7630026ed5) and [a more general article about bootloaders](http://www.embedded.com/design/prototyping-and-development/4410233/1/Bootloaders-101--making-your-embedded-design-future-proof).

### Firmware
Two firmwares will be needed: one for the cells and one for the organizer.  

### USB driver
The previous prototype has a driver, but it uses the Atmel COM port emulation of the USB port. This method is not fast enough for the Mercury, so it must be rewritten to support native USB port handling.  
In order to make this work, I need a kernel-mode driver, a user-mode dll, and a .NET wrapper.  
  
Kernel-mode drivers:  
* WinUSB (v10.0.14393, 2016-07-16, winusb.sys, comes with Windows, supports Windows only)
* libusbK  (v3.0.7, 2014-04-27, needs installation, supports Windows only)
* libusb-win32 (v1.2.6.0, 2012-01-17, needs installation, supports Linux, Mac OS X, BSDs)
  
User-mode DLLs:
* libusb (v1.0.21, 2016-12-30, supports WinUSB, libusb-win32, libusbK)
* WinUSB (v10.0.14393, 2016-07-16, winusb.dll, comes with Windows, supports WinUSB only)
* libusbK (v3.0.7, 2014-04-27, supports libusbK only)
  
.NET Wrappers:
* LibUsbDotNet (v2.2.8, 2010-10-29, wraps the newer libusb (libusb-1.0.dll), but it's incomplete)
* libusbK (v3.0.7, 2014-04-27, wraps libusbK)
* [WinUSBNet](https://github.com/madwizard-thomas/winusbnet) (v1.0.2, 2016-02-14, wraps WinUSB)

The most commonly recommended USB library for .NET is [LibUsbDotNet](https://sourceforge.net/projects/libusbdotnet/). but it's most recent version is 2.2.8, released on 2010-10-29.  
The good news is though that the libusb - which is LibUsbDotNet is based on - is still maintained at [its GitHub repo](https://github.com/libusb/libusb). The commits are recent, but the [latest Windows binaries (v1.0.21)](https://sourceforge.net/projects/libusb/files/libusb-1.0/libusb-1.0.21/) were built on 2016-12-30.  
[Libusb recommends](https://github.com/libusb/libusb/wiki/Windows) to use [libusbK](http://libusbk.sourceforge.net/UsbK3/index.html) which has C# support. Its latest version is 3.0.7 (2014-04-27).  
To generate the Windows driver I will need the latest [Zadig](http://zadig.akeo.ie/), its latest version is 2.2 (2016-01-22).  
After collecting a lot of information about the project, I think I will go with the WinUSB + WinUSB + WinUSBNet combination, because that seems to be the faster route. If it doesn't work, then I switch to WinUSB + libusb + my own wrapper for libusb. ([An issue was opened by me](https://github.com/libusb/libusb/issues/253) on GitHub to create a .NET wrapper for libusb.)  
  
On the hardware side, I could use [LUFA](http://www.fourwalledcubicle.com/LUFA.php) to send data through USB, but even its creator [@abcminiuser recommends to use ASF's USB stack](https://github.com/abcminiuser/lufa/issues/51) instead.  
  
Since 2008 there is a [USB Personal Healthcare Device Class (PHDC) standard](http://eecatalog.com/usb/2012/09/21/growth-of-usb-in-medical-devices/), which is aimed for medical devices, so I should probably implement that.  
Since 2011 Microsoft's driver supports [WCID](https://github.com/pbatard/libwdi/wiki/WCID-Devices), which is only nice-to-have, but looks cool.  
My own USB Vendor ID comes with an USB-IF membership, which [costs $4000/year](http://www.usb.org/developers/vendor/).  

### CPU and GPU FFT processor
[FFTW](http://fftw.org/) is a C subroutine library for computing the discrete Fourier transform (DFT) in one or more dimensions, of arbitrary input size, and of both real and complex data (as well as of even/odd data, i.e. the discrete cosine/sine transforms or DCT/DST).  
[clFFT](https://github.com/clMathLibraries/clFFT) is a software library containing FFT functions written in OpenCL. In addition to GPU devices, the library also supports running on CPU devices to facilitate debugging and heterogeneous programming.  
A C# wrapper will be needed to be written.

### WAV and EDF/BDF generator
I wrote a RIFF WAVE generator for the previous prototype, and with a small modification it will work perfectly with this one.  
EDF/BDF generator is a low priority for now, it would be useful only with EDFBrowser.  

### Connectivity
In order to spare as much development time as possible, connecting the Mercury to any well-developed open-source software might be a good idea.

#### [SciLab](http://www.scilab.org/)
Scilab is an open source, cross-platform numerical computational package and a high-level, numerically oriented programming language. It can be used for signal processing, statistical analysis, image enhancement, fluid dynamics simulations, numerical optimization, and modeling, simulation of explicit and implicit dynamical systems and symbolic manipulations.  
I created [a small script](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Software/Source/BBDProto05/SciLab/BBD_AnalyzeWaveInputChannels.sce) to analyze WAV data. Since I already had a WAV file generator for testing, it worked great with the generated data stream. The script isn't efficient at all, but at least it is good for basic testing.  
![Waveform, FFT and intensity display - SciLab](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto05/BBD_SciLabScreenshot.png)  

#### [ParaView](http://www.paraview.org/)  
ParaView is an open-source, multi-platform data analysis and visualization application. ParaView users can quickly build visualizations to analyze their data using qualitative and quantitative techniques. The data exploration can be done interactively in 3D or programmatically using ParaView’s batch processing capabilities.  
ParaView has awesome 3D presentation features, so it would be obvious to develop a solution where the data from Mercury would be fed to its rendering engine.  
One possible way to achieve this is to use the [OpenFOAM file format](http://cfd.direct/openfoam/user-guide/basic-file-format/#x17-1190004.2). Two readers are available: one is the built in PV4FoamReader of the [paraFoam GUI](http://cfd.direct/openfoam/user-guide/paraview/) and the other is a more optimized [Parallelized Native OpenFOAM Reader for ParaView](https://openfoamwiki.net/index.php/Contrib_Parallelized_Native_OpenFOAM_Reader_for_ParaView).  
Another option is the [VTK file format](http://www.vtk.org/VTK/img/file-formats.pdf). There is a VTK C# library called [ActiViz.NET](http://www.vtk.org/Wiki/VTK/CSharp/ActiViz.NET) which make the writing and reading of these files painless. There are [many C# examples](http://www.vtk.org/Wiki/VTK/Examples/CSharp) like the [VTP file writer](http://www.vtk.org/Wiki/VTK/Examples/CSharp/IO/WriteVTP), and here are [some example VTK files](http://people.sc.fsu.edu/%7Ejburkardt/data/vtk/vtk.html).  
It turned out that the VTK file format is old and deprecated, there is a new XML-based VTS format for the newer ParaViews. Also the ActiViz.NET package isn't free anymore they charge 1800 EURs for that if you want to get the new version unless you compile it for yourself. This option would be alright, it the publicly available source of it would be updated to use the more recent MSVC compilers, but it doesn't. I contacted Kitware and their developers are working on that at the moment, but it's still not ready to make it work with VS2010 and above (because of the missing CastXML integration).  
Because of these unfortunate developments, I decided to write my own VTS file writer and it works just fine.  
Performing FFT in ParaView is also possible, there are two public methods for it: [paraview.simple.TableFFT](http://www.paraview.org/ParaView/Doc/Nightly/www/py-doc/paraview.simple.TableFFT.html) and [paraview.simple.FFTOfSelectionOverTime](http://www.paraview.org/ParaView/Doc/Nightly/www/py-doc/paraview.simple.FFTOfSelectionOverTime.html). [In this forum](https://www.cfd-online.com/Forums/paraview/136901-fft-selection-over-time-fourier-transform-paraview-3-14-1-a.html), there is also an sample implementation. Performance-wise the FFT in ParaView is much poorer than the FFTW library I use.  
With all the challenges mentioned above, I finally was able generate a simulated 3D model animation. It also became clear that real-time streaming of the data isn't possible with ParaView 5.2, so it could be used only for post-event analysis.  
![3D model of FFT channels - ParaView](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto05/BBD_ParaViewScreenshot_01.png)  

#### [Gerbil](http://gerbilvis.org/)
In order to be able to visually present the pre-processed raw data, we will need to generate a file format which is accepted by Gerbil. The candidates are PNG and TIFF, both lossless. They can be combined in Gerbil as a hyperspectral snapshot image.
As a low priority feature it would be also great to generate an x265 MP4 in a specific frequency range. [FFmpeg](https://ffmpeg.org/) might be our friend here.

### BBD Interface
Bio Balance Detector Interface is a basic, console application. It is able to display the output of the driver, so it's well suitable for testing.  
It has a view different views and filters. In the following samples I touch the sensors and the view show the changes accordingly.  
  
Waveform View:  
![Waveform view](https://thumbs.gfycat.com/VagueLonelyAvians-size_restricted.gif)  
  
Spectrum View:  
![Spectrum view](https://thumbs.gfycat.com/ShabbyBasicGreyhounddog-size_restricted.gif)  
  
Matrix View:  
![Matrix view](https://thumbs.gfycat.com/RepentantWavyIggypops-size_restricted.gif)  
  
# Development  

## Milestones  

- [x] Stage #1 - Generator test
  - [x] Sin wave generator
  - [x] WAV file writer
- [x] Stage #2 - Connectivity
  - [x] SciLab WAV reader
  - [x] ParaView VTS file writer
- [x] Stage #3 - FFT
  - [x] FFTW filter
  - [x] Moving average filter
- [x] Stage #4 - ADC data from Mercury
  - [x] Send raw data from ADC
  - [x] Accept and reply to commands from PC
- [ ] Stage #5 - Real-time visualization
  - [x] VisualOutput console implementation
  - [ ] SignalR ouput stream
- [ ] Stage #6 - Multiple cells
  - [x] MPCM USART communication between cell (sensor-hub) and organizer
  - [ ] ChannelMapper on the organizer
- [ ] Stage #7 - Interactive parameters
  - [ ] Change sample rate on-the-fly (1k to 2M sps)
  - [ ] Change bit rate on-the-fly (8 bit, 12 bit, ~~16 bit oversampling~~)
  - [ ] Change channel number on-the-fly
  - [ ] Change channel arrangement on-the-fly
  - [ ] Change FFT size on-the-fly

## Net hours  

# Data workflow

3x3 sensors for every cell (XMEGA Kit or ATxmega64A3U) >-- 12-bit signed int ADC data trough UART --> organizer (XMEGA Kit or ATxmega256A3U) >-- 16ch x 16-bit signed int data through USB --> PC USB driver (WinUSB or libusb) >--> BBD Driver  
  
The BBD Driver is capable of using filters and redirect its output to several channels (even at the same time).  
  
The following units are implemented:  
- [x] Sources (hardware and software inputs)
  - [x] Software sine wave generator
  - [x] BBD 8x8 Matrix input (Proto#4)
  - [x] BBD Mercury-16 input (Proto#5)
- [x] Filters (data manipulation algorithms)
  - [x] Bypass filter
  - [x] Fill filter
  - [x] Moving average filter
  - [x] FFTW (CPU) filter 
- [ ] Outputs (file, visual and stream outputs)
  - [x] WAV file output
  - [x] ParaView VTS file output
  - [x] Visual output (console)
  - [ ] SignalR (WebSocket) output  
  - [ ] PNG series for Gerbil
  
# Results
* Is (a bandgap) DAC usable as an AREF to ADC?
* Is signed, differential ADC usage possible? Which pins can be used reference points? -> (possible negative inputs: ADCA0-3, ADCB0-3)

# Conclusion
* AREF is needed
* individual analog filtering is needed for the channels
* DAC for emitter on cell
* 6 pins between cells (VCC, GND, TXD, RXD, SCL, AREF)
* run [Goertzel algorithm](https://en.wikipedia.org/wiki/Goertzel_algorithm) on cell
* bandwidth is a strict limitation
* XMEGA64A4 might be not enough for the cell, so XMEGA256A4 would be better
* USB throughput is around 750 kb/s (High Speed is not supported by XMEGA)
* PHDC might be good later, but not critical
* GPU FFT might be not needed