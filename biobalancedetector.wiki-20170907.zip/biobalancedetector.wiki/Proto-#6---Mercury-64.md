Mercury-64 is a software-hardware combination to provide an up to 64-channel bio-potential reading.  

# Requirements

## Device running modes:
* 12bit, 2M SPS, time-domain streaming with 1 sensor
* 12bit, 256k SPS, time-domain streaming with 1 cell (8 sensors)
* 12bit or 16bit oversampling, 1k SPS, time-domain streaming with up to 256 cells (2'048 sensors)
* 16bit, 128 Hz, 8 frequency domain datasets with up to 256 cells (2'048 sensors)

# Hardware Components
1x [Atmel-ICE programmer and debugger](http://www.digikey.com/product-detail/en/atmel/ATATMEL-ICE/ATATMEL-ICE-ND/4753379)  
9x [ATxmega256A3BU](https://www.digikey.com/product-detail/en/microchip-technology/ATXMEGA256A3BU-AU/ATXMEGA256A3BU-AU-ND/3046475)  

## Costs

### Development costs:     

#### New Equipment: 

#### New Materials: 

#### Fabrication: 
  
### Net cost per unit

### Order(s)

# Architecture

The **cell** is a sensor-hub, so its function is to collect data from multiple sensors, connected to its ADC channels. The **organizer**, which collects the data from the cells, organizes the data and sends it through its USB interface to the PC.  
Every cell has 8 sensors and 1 emitter arranged in a 3x3 2D matrix. Cells can be daisy-chained, so the theoretical limit of cells depends only on the protocol.  

# Software components

### Firmware

### USB driver

### Connectivity
  
# Development  

## Milestones  

- [ ] Stage #1 - Antenna Design
  - [ ] Solid plate sensors
  - [ ] Fractal antenna sensors
- [ ] Stage #2 - Filter Design
  - [ ] Fixed 1 kHz LC low pass
  - [ ] Variable LC low pass
- [ ] Stage #3 - Emitter Design
  - [ ] Solid plate emitter
  - [ ] Fractal antenna emitter
  - [ ] Electromagnet emitter
- [ ] Stage #4 - PC Driver Upgrade
  - [ ] WebSocket output
- [ ] Stage #5 - Unity 3D Client
  - [ ] Basic colormap view
- [ ] Stage #6 - Firmware Optimizations
  - [ ] Sensors: Goertzel algorithm (3x per sensor)
  - [ ] Emitter: sine wave generator

## Net hours  

# Data workflow
  
# Results

# Conclusion