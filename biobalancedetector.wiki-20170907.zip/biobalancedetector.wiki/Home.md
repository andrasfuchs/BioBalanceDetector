Bio Balance Detector (BBD) is a software and hardware combination to detect, meter and show the electromagnetic energy field around human beings and indicate any potential health imbalance.

# Physical Phenomenon
The basic phenomenon isn't new or surprising. Just like in EEG and ECG/EKG we would like to measure the electromagnetic properties of a part of our body. We (and all living beings) continuously generate electromagnetic fields as we operate. This field contains a lot of information like the frequency of our brainwaves or our heart.  
The fascinating discovery is that this field changes as our emotions change and if they are maintained, they effect our bodies. [In his amazing book](https://www.amazon.com/Electrodynamic-Man-Leonard-J-Ravitz/dp/158244210X), Leonard J. Ravitz describes this in detail and from [Oschman's book](https://www.amazon.com/Energy-Medicine-Scientific-James-Oschman-ebook/dp/B018UF88AU) you can understand the whole phenomena even deeper, on the biological level.  
The bottom line is that with the advancements of our technologies we are now able to detect our states of consciousness, our mood and (according to the research) the well-being of our body, mind and soul.  

# Spirituality
Have you heard the saying "You are more then your physical body" or "You are a spirit with a body" or "Your body is just a vehicle to transport your consciousness"? We can't be sure if they are true, but with sensitive enough devices we might be able to see if there is something to those statements.  
Another author, Ildikó Hodnik goes into these questions very deeply and describes our aura-dynamics. She writes that as she could observe it, our energy field, our aura definitely does exists on many different levels. It reflects our interactions with others, our current mood, our long-kept anger or sorrow, and these negative feelings do damage our body, our organs.  

# Mission
The goal is to build a hardware which acts like a very sensitive, high resolution electromagnetic field mapper with high dynamic range. It would detect the tiny fluctuations in the electromagnetic field in its position with sensors arranged in a CCD-like matrix structure. The information gathered from the sensors would be sent to a desktop computer via USB, processed there (or on a network of computers) and displayed there, rendering an image similar to a heat-map created by an infra-camera.  
The software running on the computer would be able to show any aberrations in the field detected, close real-time.
This device would be able to help anyone with a health issue to detect the problem early on. The more exotic usage of this device would be the recording of the field changes while the patient is having an altered state of consciousness like meditation, lucid dreaming or even a near death experience.  

# Prototypes
[Proto #1 - The Color Cube (2016-01)](./Proto-%231---The-Color-Cube)  
[Proto #2 - The Intensimeter (2016-03)](./Proto-%232---The-Intensimeter)  
[Proto #3 - The 16ch Board (2016-04)](./Proto-%233---The-16ch-Board)  
[Proto #4 - The 8x8 Matrix (2016-06)](./Proto-%234---The-8x8-Matrix)  
[Proto #5 - Mercury-16 (2017-03)](./Proto-%235---Mercury-16)  
[Proto #6 - Mercury-64 (planned)](./Proto-%236---Mercury-64)  

# Roadmap
2017-08  Proto #5 - Multiple sensors, EEG-grade ADC, PC software  
2016-04  Proto #4 - 8x8 sensor panel, Arduino platform, better ADC, PC software  
2016-03  Proto #3 - Multiple sensors, Arduino platform, better ADC  
2016-02  Proto #2 - One sensor, power meter, basic ADC  
2015-12  Proto #1 - One sensor, basic ADC  
2015-09  Pre-project research  

# About me
I am a Microsoft Certified Application Developer. I mainly work on system back-ends using .NET framework and C#. After finishing my Masters Degree at the Technical University of Technology, I moved to London and to Zürich, Switzerland for a few years. Now I manage some projects of my interests, including this Bio Balance Detector.  
  
Check out my LinkedIn profile: [https://www.linkedin.com/in/andrasfuchs](http://bit.ly/29MRMbw)