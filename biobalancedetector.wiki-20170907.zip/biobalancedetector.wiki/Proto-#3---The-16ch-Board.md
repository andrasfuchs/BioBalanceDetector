Since the final goal is to have a graphical representation of the electromagnetic field changes, I needed to have as many channels as possible. The previous prototypes were good to handle one sensor only, so the next step is to extend the functionality to multiple channels.  
The 16ch board does so by using multiplexers, so 16 different channels can be measured by one ADC.

# Hardware components
The 16ch board is built around Arduino Uno. It consists of two shields: one of them has an ATtiny861 and an CD4067 16-channel multiplexer and the other has the MCP4822 DAC and the LTC1864 ADC. They are wired together and stacked on the Arduino board.  

![The 16ch board's first shield](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto03/IMG_20160414_160007.jpg)

![The 16ch board's both shields on Arduino](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto03/IMG_20160414_160038.jpg)

![The 16ch board disassembled](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto03/IMG_20160414_160118.jpg)

## Costs
New Materials: $150  
  
### Net cost per unit
$19.50 - Arduino Uno  
$_3.00 - Atmel ATtiny861  
$11.55 - Linear Technology LTC1864 ADC  
$_2.20 - Microchip MCP4822 DAC  
$_1.00 - Texas Instruments CD74HC4067 multiplexer  
$12.90 - proto shields  
$_3.50 - cables  
$_2.50 - other  
**$56.15 - TOTAL**  

# Software components
The software components got a little more complicated. Since I moved to the Arduino platform, I needed to write an Arduino C code to control the ATtiny on the shield. The ATtiny's responsibility is to communicate with the ADC and DAC through SPI and switch the multiplexer.
The Arduino code asked the ATtiny to do its job and send back the results to the Arduino board. The Arduino then processes the data and send it to the desktop through USB (Arduino's UART to be precise).
  
## Net hours  
52.2h - development (between 2016-03-24 and 2016-04-28)  
_5.0h - assembly    
**57.2h - TOTAL**  

# Workflows
As the Arduino Uno is connected and completed its setup sequence it starts to ask the shield to do one of the following: 1. change the channel, 2. get an ADC read on the selected channel, 3. set the DAC value.  
The DAC value is directly connected to the ADC's analogue reference voltage, so that is basically the changes the range and sensibility of the ADC.  
The Arduino code first sets the DAC to the default value of 5Vs, sets the channel to 0, and gets to the loop of chaning the selected channel and requesting the ADC to get a reading.
If all channels are sampled it sends the data to the UART, so the values can be processed on the PC.
At this stage the desktop application was very basic, showing only the raw data received from the Arduino.

# Results
Without the RGB LED the results were not obvious at all. Numbers were running on the screen, changing continuously for all channels.  
The data flow was working, which proved the concept but it also showed me the critical importance of the intuitive feedback. Without that it is very difficult to make sense of the data received.  
To have that area covered I need to come up with a very good representation of data.  

# Conclusion
Although the prototype was not completely finished, all its functions were tested. As a logical consequence, I could move forward to the next stage where I have 64 channels and their sensors arranged in a matrix-like pattern.