As the Color Cube could prove that the electromagnetic field can be detected around people, it needed a new way to display not just the direction of change of the field but also its intensity. The Intensimeter still has the LED just like the Color Cube, but it also has a power meter to show the absolute power of the field around its antenna. It also got a external antenna port, so I could test all the different antenna/sensor designs.

# Hardware components
The heart of the Proto #2 is Atmel ATmega168. Just like the previous version, it was assembled on a breadboard and it was programmed by an USBASP ISP programmer. The CR2032 battery power the microcontroller the LEDs and it can be charged through the ISP port.

![The Intensimeter](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto02/IMG_20160329_140355_with_text.jpg)

![The Intensimeter and its test antennas](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto02/IMG_20160329_140425.jpg)

## Costs
New Materials: $0  
  
### Net cost per unit
$_3.00 - Atmel ATmega168  
$_0.35 - 16Mhz crystal  
$_1.10 - reset button  
$_0.80 - capacitors  
$_0.60 - CR2032 battery  
$_0.25 - 2x5 IDC socket for ISP  
$_0.50 - RGB LED  
$_1.00 - indicator leds  
$_0.50 - resistance  
$_1.80 - panel  
$_1.20 - test antennas  
**$11.10 - TOTAL**  

# Software components
The only software it needed was the Atmel bytecode which was uploaded to the ATmega168 by the USBASP. The code was compiled with Atmel Studio's C compiler.  
The software averages the measured values and compares it to the currently read one. It also has a simple algorithm to calculate the RGB components of the color to set for the LED.  It also drives the intensity indicator LEDs and the heartbeat LED.
  
## Net hours  
22.1h - development (between 2016-03-09 and 2016-03-23)  
_3.5h - assembly    
**25.6h - TOTAL**  

# Workflows
The software reads the field strength by the built-in ADC continuously and calculates and sets the color of the LED, and turns on the number of power indicator LEDs needed to be turned on.
If the field strength remains roughly the same, the RGB LED keeps its green color. If the field strengthens (gets more positive) it changes to red, if it weakens it becomes green.
The antenna source can be changed and also the reference value of the ADC can be selected on the fly by changing the jumper.

# Results
The results were again promising: the LED changed its color if someone got close to the device, and the intensity indicator showed correctly if the field got weaker or stronger. The drained 3V battery was a good ADC reference voltage, better than the fairly stable USB 5V.

# Conclusion
The prototype worked as expected, so the further development is justifiable.