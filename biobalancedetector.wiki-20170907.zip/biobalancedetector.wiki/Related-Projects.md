* Open-source projects
  * [Open-BCI](http://openbci.com/) - OpenBCI stands for open-source brain-computer interface (BCI). We provide anyone with a computer, the tools necessary to sample the electrical activity of their body. Our versatile and affordable bio-sensing systems can be used to sample electrical brain activity (EEG), muscle activity (EMG), heart rate (EKG), and much more. Our 3D-printable EEG headsets can be used to get research-grade EEG recordings.  
    They use [Texas Instruments ADS1299](http://www.ti.com/product/ads1299).
  * [HackRF](http://greatscottgadgets.com/hackrf/) - "I have the HackRF and its sensitivity is worse than the RTL dongles and on top of that, it has lot more spurs."
  * [PublicLab's Spectrometer](https://publiclab.org/wiki/spectrometer)
  * [AstroCCD](http://astroccd.org/) - Dedicated to all sorts of astronomical cameras (mostly homemade) and everything that can be associated with them.
  * [Spectrum Analyzer schemantics](http://lea.hamradio.si/~s53mv/spectana/sa.html)
  * [Build your own spectrum analyzer](http://www.scottyspectrumanalyzer.com/)
  * [Opticks](https://opticks.org/)
  * [Gerbil](http://www.gerbilvis.org/) - With the powerful interactive visualization techniques in the Gerbil software, you can finally explore the raw data of your multispectral/hyperspectral image in an intuitive way. Gerbil’s rich set of algorithms including feature space transformations, dimensionality reduction, segmentation and material clustering make it the first choice for many analysis tasks.
  * [OpenLD](https://hackaday.io/project/13285-openld-lucid-dreaming-research-platform) - The Lucid Dreaming Research Platform (OpenLD) is an open-source project (GPLv3) that aims to bring the world of lucid dreaming to the Hacker community. This tool aims to assist in inducing lucid dreams and act as a means of communication between the dream and the outside world. This project utilizes an 8-channel EEG acquisition device ([Texas Instruments ADS1299](http://www.ti.com/product/ads1299)), with an on-board ARM microcontroller, along with an accompanying software that performs real-time brainwave analysis.  
Contacted the author ([Jae Choi](https://hackaday.io/Absolute0K)) on 2016-10-10 with cooperation offer, joined on 2016-10-20.
  * [EDFBrowser](github.com/andrasfuchs/EDFBrowser) - A free, opensource, multiplatform, universal viewer and toolbox intended for, but not limited to, timeseries storage files like EEG, EMG, ECG, BioImpedance, etc.
  * [Audacity](http://www.audacityteam.org/) - Audacity® is free, open source, cross-platform audio software for multi-track recording and editing.
  * [TrueSense Exploration Kit](http://www.op-innovations.com/en/TSKdesc) - The TrueSense Kit (TSK) is the first affordable, ultra-compact, ultra-low-power, bio-signal acquisition kit that allows bio-signal capturing anywhere, any time and on multiple body locations. The bio-sensor DIY kit can capture various bio-signals conveniently and has capabilities comparable to products like EEG, EKG monitors. However, the DIY kit is not considered a medical device and should not be used for monitoring or treating a medical condition.
  * [HackEEG shield for Arduino Due](https://starcat.io/products/hackeeg-shield/) - This is an Arduino Due shield for the TI ADS1299 EEG system-on-a-chip.
  * CHDK - custom, open-source firmware for Canon

* Closed source projects
  * [AirSpy](airspy.com)
  * [USB TV dongle](http://www.saankhyalabs.com/products/usb-tv-dongle-slm102uu/)
  * [USB Spectrum Analyzer](http://www.ebay.com/itm/USB-RF-Spectrum-Analyzer-3-3GHZ-/282179663955)
  * [RF Explorer](http://rfexplorer.com/) [RA124 RF rev F](http://forum.vhfdx.ru/izmeritelnaya-apparatura/analizator- spektra-signal-hound-usb-sa44b/?action=dlattach;attach=45656;image)
  * [ROHDE & SCHWARZ CRTU](https://www.rohde-schwarz.com/us/product/crtu-productstartpage_63493-8204.html)
  * [SA44](https://signalhound.com/products/usb-sa44b/)
  * [LF/MF/HF/VHF transverter](https://www.nuand.com/blog/product/hf-vhf-transverter/) - LF/MF/HF/VHF transverter (60kHz to 300MHz) - 200 USD
  * Eclosion SCIO - 11'000 EUR
  * Eclosion [Eductor](https://www.scio-eductor.com/) - 19'500 EUR
  * CaliVita Electronics [BioHarmonex](http://www.vitalland.hu/bioharmonex) - [BH3](http://www.vitalland.hu/_bioharmonex) [User's Guide](http://www.vitalland.hu/pdf/BH3HasznalatiUtmutato.pdf) - 176'000 HUF
  * Energetic Fitness Systems [EFS-300 Pro](http://energeticfitness.com/products/efs-300pro-series/)
  * [iMRS 2000](http://www.imrs2000.com/) - [review at Amazon.com](https://www.amazon.com/review/R14A977SY5N26R) - $4'000-5'000
  * AMJO [Curatron](http://www.curatron.com/curatron-family-of-products/) - [$3'250](http://www.curatron.com/prices/)
  * MAS [Special Multi](http://masmagnetics.com/product/mas-special-multi/) - $5'400
  * DENAS Complex - [Russian video](https://www.youtube.com/watch?v=KjEOkXoIHXc) - 2'800 EUR
  * DiaDENS [PCM Therapy Device](http://www.miracletherapydevices.co.uk/product.php?cat_id=1&pro_id=24) - 500 GBP
  * LENYO [Lux Plus](http://lenyo.hu/page/lenyo-lux/) - [Partners in Kecskemét](http://lenyo.hu/page/partnereink/) - Gábor Lednyiczky
  * Todd Murphy [The 8 Coil Shakti](https://www.god-helmet.com/winshakti/rotating/index.htm) - 10 nT to 1 µT
  * [Bio-Well](http://bio-well.com/) - Gas Discharge Visualization (GDV) device - 1'400 USD
  * [BEMER](https://schweiz.bemergroup.com/en) - 3'200-4'400 EUR
  * [Mora Nova](http://www.med-tronik.de/) - Today the bio-resonance therapy as energetic diagnosis and therapy method cannot be wished away from the holistic complementary medicine.MORA® NOVA offers many options that can cover various therapy fields. It gives you a reliable diagnosis and therapy.
  * [Spooky2 Advanced Kit](https://www.spooky2-mall.com/review/product/list/id/291/) - Spooky2 gives you not one, but MANY Rife machines in one package - with plasma, contact, remote, PEMF, cold laser, audio, and more. - 914 USD
  * [Berkana Labs Spooky Radionics](https://www.berkanalabs.com/spooky-radionics/) - There was a real need for a low cost, simple, and elegant radionics instrument that could directly incorporate frequency therapy. As a result Spooky Radionics was born. The 3 dial device is the first in a line of expertly engineered radionics apparatus developed by Berkana Labs for use with Spooky2. - 130 USD  
  * [Radionic accessories](http://www.kellyresearchtech.com/ka-devices.html) - Spiral antennas, sample wells  

* Other methods to detect the aura
  * [Gas Discharge Visualization (GDV) Bioelectrography](https://belvaspata.com/gas-discharge-visualization-assessment-of-healing/) by Dr. Konstantin Korotkov and Dr. Sabina DeVita