Finally the prototype got to the fabrication state. The concepts were tested with the previous versions, so it's time to build a device which has 256 channels, uses good ADC, can change it's range dynamically and communicates with the PC through USB.
For testing this version I also manufactured a 8x8 sensor matrix, that's where the name came from.

# Hardware components
The shield has a Microchip MCP4822 DAC (12bit, internal Vref, SPI) which generates the reference voltage for the Linear Technology LTC1864 ADC (16bit, 250ksps, SPI). It also has 17 Texas Instruments CD74HC4067 16 channel multiplexers that make the shield able to switch between 256 separate channels. The shield's arrangement and pinout makes it compatible with Arduino Uno.

![DAC ADC Schemantics - KiCad]
(https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto04/kicad_2016-07-13_08-10-16_DAC_ADC.png)

![PCB - KiCad]
(https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto04/kicad_2016-07-13_08-12-07_PCB.png)

![The Arduino Uno and its shield #1](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto04/IMG_20160630_091957.jpg)

![The Arduino Uno and its shield #2](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto04/IMG_20160630_092029.jpg)

![The 8x8 sensor panel](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto04/IMG_20160630_092126.jpg)

![Arduino shield and the sensor panel connected](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto04/IMG_20160630_092212.jpg)

## Costs
New Equipment: $115  
New Materials: $53  
Fabrication: $91 + $39 (on 2016-05-11 and 2016-06-14)  
  
### Net cost per unit
$_19.50 - Arduino Uno  
$_11.55 - Linear Technology LTC1864 ADC  
$__2.20 - Microchip MCP4822 DAC  
$_12.00 - 17x Texas Instruments CD74HC4067 multiplexer  
$__2.55 - 20x 16pin IDC male sockets  
$__5.90 - 4x 16pin IDC cables  
$_39.00 - shield fabrication  
$_63.50 - sensor fabrication  
**$156.20 - TOTAL**  

# Software components
I changed the software development environment for the Arduino C code to Visual Studio (using the great Arduino IDE for Visual Studio extension). Also, continued to work on the .NET code to process the raw data coming from Arduino.  
I kept the Arduino code as basic as possible to achieve the highest sample rate possible. The loop what Arduino makes is that it switches to a channel, asks the ADC to read the value on the channel, stores the value to its memory, and switches to the next channel. As soon as it finished with the sequence it sends the data to the UART.  
The data is received through the USB port, as and emulated COM. As a start I created a console application which is able to read the data from the COM port's buffer. It displays the data from the 8x8 matrix in a very basic, numeric way.  
That software is also capable of creating a standard 8000 Hz, 16 bit, 64 channel WAV file. This file can be processed with any tools capable of handling PCM WAV files.  
If the Arduino is not connected the software switches to "emulation mode" so it generates random sensor data.  
The architecture of the software is prepared to handle FFT calculations, WebRTC streams and graphical HTML-based visualizations.

![PC console software screenshot]
(https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto04/ArduinoMultiplexerServer_2016-07-13_08-02-05.png)
  
## Net hours  
52.6h - development (between 2016-04-29 and 2016-06-19)  
_5.0h - assembly    
**57.6h - TOTAL**  

# Workflows
After the Arduino setup sequence is completed, the DAC is set, and ADC starts to read data from the selected channel. After the reading is completed, it switches to the next channel, until is finished the sequence.  
If all samples from the channels are read and stored, the data is sent in a chunk to the UART, which is received on the PC on the emulated COM port of the Arduino USB port.  
The PC software makes some calculation and resampling in order to standardize the input stream to a 8000Hz, 16-bit bitstream. It is usually written to a PCM WAV file on-the-fly, but this stream will be accessible as a WebRTC stream too in the future.  
The graphical representation is planned to be an HTML-based one, but until then that's not ready, a very basic, console application is showing the data real-time.

# Results
Although the software improvements are significant, the results are a little disappointing. There is a problem with the suggestive approximation conversion and/or with the switching or the channels with the multiplexers and/or with the timing of the conversion events. Somehow the sensor values are not consistent and the channels are not totally independent. If I connect the ground to one sensor, the following 5-6 will have a significantly lower value. Theoretically they should not effect each other, but they do. I played around with the timing, and the time spent on each channel and the phenomenon got less significant, but still unacceptably strong. I have to admit, that I probably don't know enough about the inner working of the ADC to solve this problem, I need to seek some experts to help me on this.  

# Conclusion
I'm glad that the prototype was completed, and it raised new questions and many new challenges.  
As I dug deeper into the workings of the ADCs and the currently available hardware components to make very sensitive electromagnetic field fluctuation detectors, I was pleasantly surprised when I discovered [Texas Instruments' ADS1299 system-on-a-chip](http://www.ti.com/product/ads1299).  
It solved many problems already which are crucial for a project like this one, it is publicly available and I also discovered that there are a few open-source projects using it. It is not cheap, but affordable and I think a good value for money.  
My next prototype will be built around it, but for personal reasons I have to wait a year to get into it.  
Until then, if you are on a project similar to this, you are into EEG, EKG, bio-potential measurements, or you just simply exited about the idea, please don't hesitate to contact me at andras.fuchs@gmail.com.