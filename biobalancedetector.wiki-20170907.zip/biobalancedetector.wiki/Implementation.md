# Implementation Routes

## Flat Detector Panel (FDP) 
The system consists of two main parts: head module and sensor matrix. The sensor matrix is a set of sensors with their ADCs. They generate to raw data and they all send it to the head module. The head module processes and combines them. When the data is ready to be sent to the computer, it uses a standard protocol like USB to communicate with the host machine. It is also the head module's responsibility to receive and understand the commands from the host.  
The whole process works like the X-ray direct conversion when the flat-panel selenium detectors absorb x-rays directly and convert them into individual pixel electrical charges. The sensor matrix is a Flat Detector Panel (FDP) where every ADC sensor is representing a pixel of data.  
Spatial resolution will be low at the beginning of the development, but it helps to experiment with the other components of the system while maintaining a good signal-to-noise ratio (SNR). To achieve high image stability the temperature stability of ADCs, op amps and references should be high.  

## Homogeneous Electron Detector Panel  
In this configuration there is only one big sensor panel. The homogenious, low-resistant panel is surrounded by at least 4 high-speed, high-bitrate ADCs. These 4 ADC must be very presisely syncronized. At each sampling the processor estimates the charge density on the panel using the received ADC values. Interpolating the values over time would predict the density changes on the panel. This will result a density map of the panel, which is sent to the host at a given interval.  
The big advantage of the design is its simplicity, and potentially very high resolution. The disadvantage is that we would need an extremely high sample rate with very high bitrate, high quality panel with a homogeneously contant resistance and the need for a lot of post-processing.  

## Electro-Magnetic CCD  
[Charge-coupled devices, CCDs](https://en.wikipedia.org/wiki/Charge-coupled_device) are the sensors in modern digital cameras. They detect the visible segment of the electro-magnetic spectrum. 
If these CCDs could be modified to extend their range to the lower frequencies, they were a good candidate to built an elektro-magnetic field density map. That would be the direct detection method.  
Another approch to this CCD method would be the indirect detection. This would mean that the low frequency waves must be first converted into the visible range and use standard CCDs to detect them.  
The frequency detection ability of the CCD is described by its ["Detection Quantum Efficiency" (DQE)](https://en.wikipedia.org/wiki/Detective_quantum_efficiency). This is a combination of its core cell characteristics, its [Bayer-filter](https://en.wikipedia.org/wiki/Bayer_filter), the noise reduction circuits and even its operating temperature. After checking the currently available CCDs' DQE it looks like that the CCD approch is not feasable at the moment.

# Useful information
  * [Direct vs Indirect Conversion](http://www.ti.com/solution/x_ray_medical_dental)
  * [Daisy-chaning ADCs](http://electronics.stackexchange.com/questions/129324/daisy-chaining-adc-sensors)
  * [ADC for Xmega](https://eewiki.net/display/microcontroller/ADC+Example+for+Xmega)
  * [LTC2400, 5SPS, 24bit ADC for Arduino](http://interface.khm.de/index.php/lab/interfaces-advanced/connect-a-ltc2400-high-precision-24-bit-analog-to-digital-converter/) - Connect a LTC2400 High Precision 24 bit Analog to Digital Converter to Arduino

# XMEGA related topics

## XMEGA Clocks and their settings

The clock frequency can be defined as a 1x to 31x multiple of the clock source's frequency. The clock source will be the internal 32Mhz oscillator (SCK_SEL[2:0] = 001) and the multiplication factor is defined by the PLL (phase locked loop). If the PLL's source is the 32Mhz, it is divided by 4 by default, so the _theoretical_ maximum clock speed is (32/4) * 31 = 248Mhz, but the highest documented speed for the XMEGA family is 70Mhz. PLL_FAC is the multiplier's name, so to have 32Mhz clk(sys), we must set it to 4, and select the internal 32Mhz oscillator as source.  
Oscillator failure monitoring must be enabled (XOSCFAIL register) all times, because we might want to overclock the u-controller to reach higher bandwidth.  
USART will be used in synchronous mode to achieve its maximum baud rate (BSCALE=0, BSEL=0). Baud rate is f(per)/2. Synchronous (half-duplex) operation needs 2 pins: XCK and RxD/TxD.  
We also need to make USB work, which needs a 48Mhz clock. According to AVR1017, section 3.2.2, we should calibrate the internal 32Mhz RC oscillator to 48Mhz using the internal DFLL (digital frequency looked loop). CPU clock must be at least 12Mhz for the USB to work.  
To have the 32Mhz clk(cpu) we will need to use the 2Mhz internal oscillator instead and set the PLL to 16 or higher. This sets our maximum overclocked CPU speed to 2 * 31 = 62Mhz. PLL's range is 20Mhz to 128Mhz.  
According to the XMEGA specs' 10.2 section, the following values will be needed:  
* USB clock: 32Mhz internal oscillator DFLL'd to 48MHz, USB prescaler = 0, clk(USB) = 48Mhz.
* CPU clock: 2Mhz internal oscillator DFLL'd to 2MHz, PLL'd to 32Mhz, clk(sys) = 32Mhz, clk(CPU) = 32Mhz.
* USART clock: clk(sys) = 32Mhz, clk(per) = 32Mhz, so it's synchronous baud rate is f(baud) = 16Mbps
* ADC clock: clk(sys) = 32Mhz, clk(per) = 32Mhz, valid clock prescalers are 1/4 to 1/512 using clk(per) as source, generating clk(ADC). Conversion cycles are the following: 5 cycles/sample (8 bit, no gain) or 7 cycles/sample (12 bit, no gain) or 9 cycles/sample (12 bit, 32x or 64x gain), but they are not that significant thanks to the ADC's pipelined architectures, so we can make a sample at every cycle in free running mode. The clk(ADC)'s range is 100kHz to 2MHz.  

## MPCM: Multiprocessor communication mode

1 start bit + 9 data bits + parity + 1 stop bit frame looks practical since the addressing needs and the ninth data bit in the frame to indicate if it's an address (1) or data (0). We can address 256 slaves this way, which means 8x256 sensors per organizer.  
  
The following procedure should be used to exchange data in multiprocessor communication mode (MPCM):  

1. All slave MCUs are in multiprocessor communication mode.  
2. The master MCU sends an address frame, and all slaves receive and read this frame.  
3. Each slave MCU determines if it has been selected.  
4. The addressed MCU will disable MPCM and receive all data frames. The other slave MCUs will ignore the data frames.  
5. When the addressed MCU has received the last data frame, it must enable MPCM again and wait for a new address frame from the master.  

## ADC
The two ADCs in the XMEGA-As are 2MSPS, 12bit analog to digital converters. If we wanted to have 16 bit samples, we would have 2MSPS/256=8kHz sample rate. If we switch the ADC to 8-bit mode, the conversion would be slightly faster, but because of the pipelined architecture we would not win nearly anything by it. All in all, the higher resolution is less important than the high sample rate, so the target would be the 12bit sample rate with the highest sample rate possible.  
The two ADCs have 2x4 separate channels with their own result registers, so that's the maximum number of sensors that can be attached to one XMEGA, if we want to maintain the high sample rate.  
We are going to the internal 1V reference voltage (? or the internal DAC output?), so the conversion will be single-ended and in that case the results must be unsigned. This means that the value 0 will represent GND and the value 2^12=4096 will be 1V (? or the DAC setting?). To be precise result = (V(input) + V(delta))/V(reference) * 4096, where V(delta) = (200/4096) * V(reference). V(delta) is the typical offset value of the channel in unsigned mode.  
Input channels must use 5,6,7,8 ports of each ADC.  
Using signed mode is not beneficial, because "Negative values are not negative inputs on the I/O pins, but higher voltage level on the negative input in respect to the positive input. Even though the resulting value can be negative, voltages below GND or above VCC should under no circumstances be applied to any input port." (From AVR 1300, section 1.3 Conversion Mode)  
To achieve the maximum rate ADCs will be in free running, sweeping modes at 2MSPS, so the result registered are filled as often as possible.   
Result registers then will be read at regular intervals, set by the timer counter.  
According to the specification the lowest ADC clock speed of the XMEGA-A is 100kHz.  
The highest effective speed what I could achieve with ADC polling and USB bulk transfer to the PC (with C# WinUSB polling) was 51kHz (while the ADC running at 2MHz) at 795 kbyte/s (6.36 Mbit/s).
Alternatively to the result registers of ADC results can be written into memory using DMA.  

# Serial transfer options

There are a few data transport options ([good summary here](http://electronics.stackexchange.com/questions/37814/usart-uart-rs232-usb-spi-i2c-ttl-etc-what-are-all-of-these-and-how-do-th/37817#37817)):
* TWI/I2C: only two wires are needed (clock and data), 128 slave addresses are allowed (can be extended to 1024), the officially supported maximum clock speed is 400kHz on XMEGAs.  
The [I2C speed grades](http://www.i2c-bus.org/speed/) are: standard mode: 0.1Mbps, full speed: 0.4Mbps, fast mode: 1Mbps, high speed: 3.2Mbps.
* UART: maximum speed is 32Mhz/16=2Mbps or 32Mhz/8=4Mbps (in asynchronous double speed mode). According to [this article](http://electronics.stackexchange.com/questions/9703/multi-node-bus-options) both the more complex 2-wire [CAN](https://en.wikipedia.org/wiki/CAN_bus) and simpler 2-wire [RS-485](https://en.wikipedia.org/wiki/RS-485)([rs485lib](http://www.computers-n-robots.de/rs485libwinavr/rs485libwinavr.html)) can be implemented using UART. Here is a [great AVR UART tutorial](http://maxembedded.com/2013/09/the-usart-of-the-avr/) and a [baud rate calculator](http://wormfood.net/avrbaudcalc.php/?bitrate=100k%2C400k%2C1m%2C2m%2C4m%2C8m%2C16m%2C32m&clock=32&databits=8).
* USART: maximum master speed is 32Mhz/2=16Mbps, slave speed is 32Mhz/4=8Mbps. It also has a slave addressing protocol, where 8 bit data must be accompanied by 1 start + 1 frame + 1 parity + 1 stop bits, making the effective net speed limit (8/12) * 16 = 5.33Mbps. USART needs three wires: TxD, RxD, XCK. There must be only one master on any USART bus, who generates the clock on XCK.  
* SPI (uses USART): three (or four) wires are needed (clock, data, slave select), every slave needs a pin on master, max clock speed is 32Mhz/2=16Mbps for the SPI master and 32Mhz/4=8Mbps for the SPI slaves.
* [Daisy-chain SPI](https://en.wikipedia.org/wiki/Serial_Peripheral_Interface_Bus#Daisy_chain_configuration): four wires independently from the number of slaves.
* USB: USB 2.0, Full speed, 12Mbps (with bulk transfers). To reach full speed [ASF changes (or used to change) the clock speed to 24Mhz and the USB oscillator to 48Mhz](http://www.avrfreaks.net/forum/overclocking-xmega).  

TWI runs at 400kHz could theoretically produce a little less than 400kbps, but that would be still too low, when we multiply the number of sensors in the future.  
SPI's biggest disadvantage is the slave select pin and the use of four pins. There is a three-wire, half-duplex version which is better, but still, that would also need a separate slave select pin on the master which also would prevent us from daisy-chaining the cells.  
RS-485 uses UART, so that's pretty fast (2-4Mbps) and it supports addressing.  
USART's MPCM mode is even more promising with its 5.3Mbps speed, USART is also buffered, not like SPI, so that is our most likely candidate.  

## USB transfer
### USB modes and speeds:  

|    Mode     | USB | Mbit/s | Mbyte/s | bulk packet size | isoch packet size | isoch service interval | isoch speed |
|:------------|----:|-------:|--------:|-----------------:|------------------:|-----------------------:|------------:|
| Low Speed   | 1.0 |    1.5 |  0.1875 |                  |                   |          255ms to 10ms |             |
| Full Speed  | 1.1 |     12 |     1.5 |    8, 16, 32, 64 |        1023 bytes |          255ms to  1ms | 1M packet/s |
| Hi-Speed    | 2.0 |    480 |      60 |              512 |        1024 bytes |            4s to 125us | 8M packet/s |
| SuperSpeed  | 3.0 |  5'120 |     640 |             1024 |        1024 bytes |            4s to 125us | 8M packet/s |
| SuperSpeed+ | 3.1 | 10'240 |   1'028 |             1024 |        1024 bytes |            4s to 125us | 8M packet/s |

Due the transfer frames 90% of those speed are realistically possible.  

### Bulk vs Isochronous transfers
Bulk Transfers are used for data which are not of the type Control, Interrupt, or Isochronous. Reliable exchange of data is ensured at the hardware level using error detection. Bulk Transfers take up all the bandwidth that is available after the other transfers have finished. If the bus is very busy, then a Bulk Transfer may be delayed.  

Isochronous Transfers are used for transmitting real-time information such as audio and video data, and must be sent at a constant rate. USB isochronous data streams are allocated a dedicated portion of USB bandwidth to ensure that data can be delivered at the desired rate. An Isochronous pipe sends a new data packet in every frame, regardless of the success or failure of the last packet.  

Every isochronous endpoint can represent only one (?) channel of streaming data. The maximum number of interfaces per USB 2.0 device is 256, and the maximum number of endpoints per interface is 16. So the maximum number of supported channels is 256*16 = 4'096.  
USB 3.0 pushes 48 of 1024 byte packets during a 125us microframe in isochronous mode. (A 1ms frame contains 8x125us microframes.)  

More information about isochronous endpoints: https://msdn.microsoft.com/en-us/library/windows/hardware/hh406225(v=vs.85).aspx  

### USB 3.0 Stream Protocol

SuperSpeed streaming is like an extension of a logical Bulk endpoint, and can multiplex multiple independent logical data streams. The protocol supports between 1 and 65,533 streams.  

## DMAC, external flash and USART
XMEGA has a Direct Memory Access Controller (DMAC). This makes it possible to move around data with very low CPU usage. This sounds like a wonderful feature for us, because we will need the following transactions:  
* Cell: get the ADC's results and store them in the internal RAM or external flash
* Cell: send data from internal RAM/external flash to USART buffer  
* Organizer: get data from USART buffer into external flash  
* Organizer: send data from external flash to USB  

The internal memory of the XMEGA256A3 is 16 kbytes, but only approximately 14 kbytes will be available for result caching, which means 896 samples. The XMEGA64A3 has only 4 kbytes, 2 kbytes for the only 128 samples.  
If that is not sufficient, then a cell's price will increase, because every cell then would need a flash memory attached to it. Too much memory is pointless, since we should keep a high refresh rate anyways on the PC, so for example if our goal is 50 fps at 1Msps, the maximum memory requirement would be 8 * 16 bit * 1'000'000 / 50 = 2.56 Mbit = 320 kbytes.  
SPI serial flashes are not cheap and we would need them on every cell, so this is going to be a though call.  

|  type  |  size   |  size (bytes) | price |   
|:------:|--------:|--------------:|------:|  
| AT45DB |  2 Mbit |    256 kbytes | [$1.08](http://www.digikey.com/product-detail/en/adesto-technologies/AT45DB021E-SHN-B/AT45DB021E-SHN-B-ND/3854969) |  
| AT45DB |  4 Mbit |    512 kbytes | [$1.12](http://www.digikey.com/product-detail/en/adesto-technologies/AT45DB041E-SHN-B/1265-1066-5-ND/4340614) |  
| AT45DB |  8 Mbit |   1024 kbytes | [$1.45](http://www.digikey.com/product-detail/en/adesto-technologies/AT45DB081E-SHN-B/1265-1103-5-ND/4439499) |  
| AT45DB | 16 Mbit |   2048 kbytes | [$2.20](http://www.digikey.com/product-detail/en/adesto-technologies/AT45DB161E-SHF-B/1265-1069-5-ND/4340617) |  
| AT45DB | 32 Mbit |   4096 kbytes | [$2.82](http://www.digikey.com/product-detail/en/adesto-technologies/AT45DB321E-SHF-B/1265-1072-5-ND/4340620) |  
| AT45DB | 64 Mbit |   8192 kbytes | [$4.24](http://www.digikey.com/product-detail/en/adesto-technologies/AT45DB641E-SHN-B/1265-1185-5-ND/4901482) |  
| AT25DF |  8 Mbit |   1024 kbytes | [$1.08](https://www.digikey.com/product-detail/en/adesto-technologies/AT25DF081A-SSH-B/1265-1020-5-ND/3828576) |  
| AT25DF | 64 Mbit |   8192 kbytes | [$4.31](https://www.digikey.com/product-detail/en/adesto-technologies/AT25DF641A-SH-B/1265-1047-ND/3986550) |  

# IEEE 11073 - Personal Health Data (PHD) Standards

This standard defines which packet structures are allowed to communicate between devices regarding personal health. It is physical layer independent, so it can be used over USB, TCP/IP or Bluetooth.  
The hardware device is called the Agent, and host computer is called the Manager.  
  
IEEE/ISO has a [search engine](https://www.iso.org/obp/ui/#search) to find and buy all the documents relating to the standard.  
  
Wikipedia also has an [overview article](https://en.wikipedia.org/wiki/ISO/IEEE_11073_Personal_Health_Data_(PHD)_Standards#Architectural_overview) about the it.  
  
There is an open-source C library called [Antidote](http://oss.signove.com/index.php/Antidote_IEEE_11073_stack_library), available on a [git repo](https://gitorious.org/antidote/antidote).  

All packets start with a 16-bit identifier or choice, followed another 16-bit unsigned integer, indicating the size of the data that follows them.  
  
0xE200 - Association Request (Agent)  
0xE300 - Association Response (Manager)  
0xE400 - Association Release Request (Agent)  
0xE500 - Association Release Response (Manager)  
0xE600 - Association Abort (Manager)  
0xE700 - Send Data (Agent or Manager)  
  
# Antenna 
Designing an antenna is a challenge. We would need one which is as frequency independent as possible. The antennas used in these cases are [the fractal or frequency independent antennas](https://en.wikipedia.org/wiki/Fractal_antenna  
).  
There is a paper about the parametering of fractal antennas: [Self-similarity and the geometric requirements for frequency independence in antennae (1999)](http://www.worldscientific.com/doi/pdf/10.1142/S0218348X99000098) for 30 USD.  
[Fractal antenna constructions (2007)](http://www.scienceprog.com/fractal-antenna-constructions/)  
Everything about antenna design:  [Joseph Carr, George Hippisley - Practical Antenna Handbook 5/e (2011)](
https://www.amazon.com/Practical-Antenna-Handbook-Joseph-Carr-ebook/dp/B0069QEH8A/ref=cm_wl_huc_item) for 29 USD  
[Fractal Antenna Aims At 2.9 To 14.6 GHz (2012)](http://mwrf.com/passive-components/fractal-antenna-aims-29-146-ghz)  
[Fractal antenna experiment](http://www.m0wwa.co.uk/page/M0WWA_fractal_antenna.html)  
[Generated Fractal Examples](http://www.fractal.org/Fractal-tree-scaffold.htm)  
[Fractal Generator](http://www.kevs3d.co.uk/dev/lsystems/)  
![Fractals in nature](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Hardware/Design/fractals-in-nature-wallpapers-full-hd.jpg)
  
# Magnetic field generation
The magnetic field will be generated by a small coil at the center of each cell. The generated strength should be around 35uT at 2.9V on a 3cm x 3cm surface. According to the XMEGA datasheet (36.1.5) the I/O pins' output voltage range is 0.4(low)-2.9(high) and their current is -20mA and +20mA when the Vcc is 3.3V.  
The DAC which will be used to generate the signal for the inductor (unshielded or partially shielded, SMD) has slightly different characteristics: output voltage is between 0.15V and AVcc-0.15V (3.15V), maximum 50 Ohm impedance and 10mA current. If the current is not enough, it is recommended to use a cheap transistor like 2N3904/6 or 2N4401/2.  
We would like to generate pulsating magnetic fields with frequencies between 0.5 and 40Hz. This means, that we need an insulator configuration which allow to signal to change so quickly the every bit-change on the DAC will be represented, even if it's sine wave is 40Hz or more. The DAC's resolution is 12-bit, this means 2^12=4096 different possible values, the smallest time interval we would need is (1 second / 40 * 4096).      
  
Tesla = (Volt * second) / (meter * meter) = (Henry * Ampere) / (meter * meter)  
3.15 Volts * (1/(40 * 4096)) seconds = Henry * 10 milliAmpere  
Henry <= (3.15 * 1/40) / 0.01  
Henry <= 0.019226  
  
35 uTesla <= Henry * 0.01 / (0.03 * 0.03)  
Henry >= 0.000035 / 0.01 * 0.0009  
Henry >= 0.00000315  
  
3.15 uH <= Henry <= 19.23 mH (@  10mA), but since the inductors are typically rated in the 50mA+ range  
0.630 uH <= Henry <= 3.846 mH (@  50mA) and  
0.315 uH <= Henry <= 1.923 mH (@ 100mA)

To confirm that the calculation was right, we should use a [magnetic probe](http://www.vernier.com/products/sensors/magnetic-field-sensors/mg-bta/) to get the exact Tesla value above the inductor. Another things to keep in mind that the magnetic field generated could make noise in the XMEGA if it is not shielded and/or not positioned properly.  

# Analog Signal Filtering
Analog signal processing will be needed, because we limit our sampling rate so we need to implement an [anti-alias filter](https://en.wikipedia.org/wiki/Anti-aliasing_filter). Since we are interested in all low frequency signals, this could be achieved by a low-pass filter.  
According to the [Nyquist–Shannon sampling theorem](https://en.wikipedia.org/wiki/Nyquist%E2%80%93Shannon_sampling_theorem), if we are interested in the frequency range of 0-500 Hz, we need at least 1000 samples/second sampling rate, twice the higher bound of our range. XMEGA's ADC is capable to sample at the rate of 2 million samples/second, so our hard limit is 0 Hz - 1 Mhz.  
The problem is with a phenomena of 'aliasing'. This means that if we have an antenna which is able to capture electromagnetic waves above our ADC's maximum (in our case 1 MHz) those waves will add noise to our samples. To avoid this, there are several types of analog filters available, like [Bessel, Butterworth and Chebyshev](http://www.dspguide.com/ch3/4.htm). Unfortunately these filter always will distort our signal in the range we want to capture too. The better the quality of the analog filter, the less distortion we are going to have.   
From the above 3 designs, Butterworth is the maximally flat magnitude filter. This means that it will have the lowest generated ripples during filtering which is critical for our use case. The other quality parameter of these filters is that how sharply can they cut the frequencies. This parameter can be improved by making the filter circuit more complicated and more expensive. The most basic is called a first-order filter, the little better is the second-order, and so on. Numerically this means that the first-order filter's response rolls off at −6 dB per octave, the second-order filter decreases at −12 dB per octave, a third-order at −18 dB and so on.  
Decibel (dB) is a logarithmic unit used to express the ratio of two values of a physical quantity. -20 dB means that the signal's amplitude became 10% of the original. -40 dB means that it became 1% of it.
The frequency band we don't want to filter is called the passband, the part we want to filter is the stopband. The exact frequency where we want to make the cut is called the angular frequency, the frequency where we first reach the -3dB is the cutoff frequency.   
![Butterworth low-pass orders 1-5](https://upload.wikimedia.org/wikipedia/commons/c/cd/Butterworth_Filter_Orders.svg)
So, let's suppose the we have a sampling rate of 1000 Hz. Theoretically we would be able to detect waves between 0 and 500 Hz. We want to make sure by filtering that only waves between 0 and 500 Hz reach our ADC. It's not 100% possible with analog filtering, but still, let's say that we accept 1% noise, so we need to weaken all signals above 500 Hz at least by -40 dB. According our numbers to have -40 dB at 500 Hz we must set our angular frequency to a lower value. How much lower than 500 Hz? It depends on the quality of the filter, so it's order (number of poles).  
[The x100 attenuation ratio](http://www.dspguide.com/graphics/T_3_2.gif) for 2,4,6 and 8 poles are 10.0, 3.17, 2.16 and 1.78 accordingly. This means the our angular frequency must be 500/1.78 = 280 Hz or less, if we have a good quality 8th-order Butterworth filter. The bad news is that in this case we should discard the measured values between 280 Hz and 500 Hz too, because they will be also attenuated.  
  
A good candidate active filter IC for this implementation would be the [Maxim MAX295](https://www.maximintegrated.com/en/products/analog/analog-filters/MAX295.html/tb_tab0). The good is that it is a 8th-order Butterworth low-pass filter with programmable cut-off frequency between 0.1Hz and 50kHz, it has a 8-pin SO package and the bad is that it has only 1 filter section (channel) and the power supply must be 5V.  
There are some other [active filters at DigiKey](https://www.digikey.com/products/en/integrated-circuits-ics/interface-filters-active/735?FV=1140003%2C5dc0005%2C1f140000%2Cffe002df&mnonly=0&ColumnSort=1000002&page=1&stock=0&pbfree=0&rohs=0&cad=0&datasheet=0&nstock=0&photo=0&nonrohs=0&newproducts=0&quantity=1&ptm=0&fid=0&pageSize=50).