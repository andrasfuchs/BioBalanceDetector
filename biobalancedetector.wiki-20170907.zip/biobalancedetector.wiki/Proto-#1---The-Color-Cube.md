The primary purpose of the Color Cube was to prove that the physical phenomena is there and it is measurable. It has a small antenna to measure the electromagnetic field around itself, and changes it's LED's color according the change.

# Hardware components
The heart of the Proto #1 is Atmel ATtiny85. The whole thing was assembled on a breadboard and it was programmed by an USBASP ISP programmer. Later it was modified to run on a CR2032 battery and it got a nice plastic case.

![ATtiny on a breadboard](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto01/Tests_v2/IMG_20151227_225511.JPG)

![The cube from above](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto01/Tests_v3/image-20160119_134415.jpg)

![The cube from the side](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto01/Tests_v3/image-20160119_134434.jpg)

![USBASP pinout](https://github.com/andrasfuchs/BioBalanceDetector/blob/master/Photos/Proto01/USBASP/USBASP_ATtiny85.png)

## Costs
New Equipment: $121  
New Materials: $87  
  
### Net cost per unit
$1.00 - Atmel ATtiny85-20PU  
$0.60 - CR2032 battery  
$1.00 - micro switch  
$0.25 - 2x5 IDC socket for ISP  
$0.50 - RGB LED  
$0.90 - panel  
$1.00 - cover  
**$5.25 - TOTAL**  

# Software components
The only software it needed was the Atmel bytecode which was uploaded to the ATtiny85 by the USBASP. The code was compiled with Atmel Studio's C compiler.  
The software averages the measured values and compares it to the currently read one. It also has a simple algorithm to calculate the RGB components of the color to set for the LED.  
  
## Net hours  
5.0h - development (between 2015-12-12 and 2016-01-20)  
1.5h - assembly    
**6.5h - TOTAL**  

# Workflows
The software reads the field strength by the built-in ADC continuously and calculates and sets the color of the LED.
If the field strength remains roughly the same, the LED keeps its green color. If the field strengthens (gets more positive) it changes to red, if it weakens it becomes green.

# Results
The results clearly indicated that we as human beings can change the strength of an electromagnetic field be getting closer or more away from the sensor. It was easily demonstrated if only one person was present and he moved this hands to approximately 30cm to the device or move his whole body around it at even 50cms.  
Interestingly if there were more people around the device it was not consistent and often got "trapped" in a state of red or blue.

# Conclusion
The prototype served it's purpose: detected and indicated correctly changes in the electromagnetic fields around us.
Since it can only show the relative changes in the field and it got trapped sometimes, the next improvement should be an absolute indicator of these field while still having a LED to show the relative changes.