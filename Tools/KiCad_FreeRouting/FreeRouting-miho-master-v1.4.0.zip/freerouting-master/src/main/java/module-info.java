//module eu.mihosoft.freerouting {
//   requires java.desktop;
//   requires java.logging;
//   requires eu.mihosoft.freerouting.deps.jh;
//}
