#include "lusbk_version.h"

#define ID_HELP_TEXT  10020
#define ID_DOS_TEXT   300
